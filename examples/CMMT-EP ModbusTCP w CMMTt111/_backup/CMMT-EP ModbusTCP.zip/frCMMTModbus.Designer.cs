﻿namespace CMMT_EP_ModbusTCP
{
    partial class frCMMTModbus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frCMMTModbus));
            this.btConnect = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txExtendedOW = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txExtendedIW = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txIPAddress = new System.Windows.Forms.TextBox();
            this.tCycle = new System.Windows.Forms.Timer(this.components);
            this.ssStatus = new System.Windows.Forms.StatusStrip();
            this.lbStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txRawIn = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txVelocityOutputFG = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txVelocityInputFG = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txPositionOutputFG = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txPositionInputFG = new System.Windows.Forms.TextBox();
            this.gbSetting = new System.Windows.Forms.GroupBox();
            this.lbSettingPrev = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txPort = new System.Windows.Forms.TextBox();
            this.lbSettingNext = new System.Windows.Forms.Label();
            this.gbControl = new System.Windows.Forms.GroupBox();
            this.cbEnableDrive = new System.Windows.Forms.CheckBox();
            this.gbDebug = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpRaw = new System.Windows.Forms.TabPage();
            this.txRawOut = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tpSTW1 = new System.Windows.Forms.TabPage();
            this.cbSTW1Write = new System.Windows.Forms.CheckBox();
            this.cbSTW1_15 = new System.Windows.Forms.CheckBox();
            this.cbSTW1_14 = new System.Windows.Forms.CheckBox();
            this.cbSTW1_13 = new System.Windows.Forms.CheckBox();
            this.cbSTW1_12 = new System.Windows.Forms.CheckBox();
            this.cbSTW1_11 = new System.Windows.Forms.CheckBox();
            this.cbSTW1_10 = new System.Windows.Forms.CheckBox();
            this.cbSTW1_9 = new System.Windows.Forms.CheckBox();
            this.cbSTW1_8 = new System.Windows.Forms.CheckBox();
            this.cbSTW1_7 = new System.Windows.Forms.CheckBox();
            this.cbSTW1_6 = new System.Windows.Forms.CheckBox();
            this.cbSTW1_5 = new System.Windows.Forms.CheckBox();
            this.cbSTW1_4 = new System.Windows.Forms.CheckBox();
            this.cbSTW1_3 = new System.Windows.Forms.CheckBox();
            this.cbSTW1_2 = new System.Windows.Forms.CheckBox();
            this.cbSTW1_1 = new System.Windows.Forms.CheckBox();
            this.label22 = new System.Windows.Forms.Label();
            this.cbSTW1_0 = new System.Windows.Forms.CheckBox();
            this.tpZSW1 = new System.Windows.Forms.TabPage();
            this.cbZSW1_9 = new System.Windows.Forms.CheckBox();
            this.cbZSW1_15 = new System.Windows.Forms.CheckBox();
            this.cbZSW1_14 = new System.Windows.Forms.CheckBox();
            this.cbZSW1_13 = new System.Windows.Forms.CheckBox();
            this.cbZSW1_12 = new System.Windows.Forms.CheckBox();
            this.cbZSW1_10 = new System.Windows.Forms.CheckBox();
            this.cbZSW1_11 = new System.Windows.Forms.CheckBox();
            this.cbZSW1_8 = new System.Windows.Forms.CheckBox();
            this.cbZSW1_7 = new System.Windows.Forms.CheckBox();
            this.cbZSW1_6 = new System.Windows.Forms.CheckBox();
            this.cbZSW1_5 = new System.Windows.Forms.CheckBox();
            this.cbZSW1_4 = new System.Windows.Forms.CheckBox();
            this.cbZSW1_3 = new System.Windows.Forms.CheckBox();
            this.cbZSW1_2 = new System.Windows.Forms.CheckBox();
            this.cbZSW1_1 = new System.Windows.Forms.CheckBox();
            this.cbZSW1_0 = new System.Windows.Forms.CheckBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tpPSTW1 = new System.Windows.Forms.TabPage();
            this.cbPSTW1Write = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_15 = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_14 = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_13 = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_12 = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_11 = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_10 = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_9 = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_8 = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_7 = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_6 = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_5 = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_4 = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_3 = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_2 = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_1 = new System.Windows.Forms.CheckBox();
            this.cbPSTW1_0 = new System.Windows.Forms.CheckBox();
            this.label24 = new System.Windows.Forms.Label();
            this.tpPZSW1 = new System.Windows.Forms.TabPage();
            this.cbPZSW1_15 = new System.Windows.Forms.CheckBox();
            this.cbPZSW1_14 = new System.Windows.Forms.CheckBox();
            this.cbPZSW1_13 = new System.Windows.Forms.CheckBox();
            this.cbPZSW1_12 = new System.Windows.Forms.CheckBox();
            this.cbPZSW1_11 = new System.Windows.Forms.CheckBox();
            this.cbPZSW1_10 = new System.Windows.Forms.CheckBox();
            this.cbPZSW1_9 = new System.Windows.Forms.CheckBox();
            this.cbPZSW1_8 = new System.Windows.Forms.CheckBox();
            this.cbPZSW1_7 = new System.Windows.Forms.CheckBox();
            this.cbPZSW1_6 = new System.Windows.Forms.CheckBox();
            this.cbPZSW1_5 = new System.Windows.Forms.CheckBox();
            this.cbPZSW1_4 = new System.Windows.Forms.CheckBox();
            this.cbPZSW1_3 = new System.Windows.Forms.CheckBox();
            this.cbPZSW1_2 = new System.Windows.Forms.CheckBox();
            this.cbPZSW1_1 = new System.Windows.Forms.CheckBox();
            this.cbPZSW1_0 = new System.Windows.Forms.CheckBox();
            this.label26 = new System.Windows.Forms.Label();
            this.tpPSTW2 = new System.Windows.Forms.TabPage();
            this.cbPSTW2Write = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_15 = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_14 = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_13 = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_12 = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_11 = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_10 = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_9 = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_8 = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_7 = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_6 = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_5 = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_4 = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_3 = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_2 = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_1 = new System.Windows.Forms.CheckBox();
            this.cbPSTW2_0 = new System.Windows.Forms.CheckBox();
            this.label25 = new System.Windows.Forms.Label();
            this.lbDebugPrev = new System.Windows.Forms.Label();
            this.lbDebugNext = new System.Windows.Forms.Label();
            this.gbDynamic = new System.Windows.Forms.GroupBox();
            this.lbDynamicPrev = new System.Windows.Forms.Label();
            this.lbDynamicNext = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lbUnitVel = new System.Windows.Forms.Label();
            this.lbUnitPos = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txUnitVel = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txUnitPos = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txTargetPosition = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txTargetVelocity = new System.Windows.Forms.TextBox();
            this.txOverride = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txDec = new System.Windows.Forms.TextBox();
            this.txAcc = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cbTakeControl = new System.Windows.Forms.CheckBox();
            this.gbConnect = new System.Windows.Forms.GroupBox();
            this.gbTakeControl = new System.Windows.Forms.GroupBox();
            this.btGo = new System.Windows.Forms.Button();
            this.tsCmmtStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.label27 = new System.Windows.Forms.Label();
            this.rbMoveAbsolute = new System.Windows.Forms.RadioButton();
            this.rbMoveRelative = new System.Windows.Forms.RadioButton();
            this.rbRecordSelection = new System.Windows.Forms.RadioButton();
            this.rbHoming = new System.Windows.Forms.RadioButton();
            this.btStop = new System.Windows.Forms.Button();
            this.btClear = new System.Windows.Forms.Button();
            this.btAck = new System.Windows.Forms.Button();
            this.gbMode = new System.Windows.Forms.GroupBox();
            this.txRecordSelection = new System.Windows.Forms.TextBox();
            this.gbStatus = new System.Windows.Forms.GroupBox();
            this.lbHomingStatus = new System.Windows.Forms.Label();
            this.btJog2 = new System.Windows.Forms.Button();
            this.btJog1 = new System.Windows.Forms.Button();
            this.lbMoveStatus = new System.Windows.Forms.Label();
            this.lbRecordSelectionStatus = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.ssStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.gbSetting.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.gbControl.SuspendLayout();
            this.gbDebug.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tpRaw.SuspendLayout();
            this.tpSTW1.SuspendLayout();
            this.tpZSW1.SuspendLayout();
            this.tpPSTW1.SuspendLayout();
            this.tpPZSW1.SuspendLayout();
            this.tpPSTW2.SuspendLayout();
            this.gbDynamic.SuspendLayout();
            this.gbConnect.SuspendLayout();
            this.gbTakeControl.SuspendLayout();
            this.gbMode.SuspendLayout();
            this.gbStatus.SuspendLayout();
            this.SuspendLayout();
            // 
            // btConnect
            // 
            this.btConnect.Location = new System.Drawing.Point(56, 34);
            this.btConnect.Name = "btConnect";
            this.btConnect.Size = new System.Drawing.Size(115, 42);
            this.btConnect.TabIndex = 0;
            this.btConnect.Text = "Connect";
            this.btConnect.UseVisualStyleBackColor = true;
            this.btConnect.Click += new System.EventHandler(this.BtConnect_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txExtendedOW);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txExtendedIW);
            this.groupBox2.Location = new System.Drawing.Point(21, 148);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(261, 110);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Extended Parameter";
            // 
            // txExtendedOW
            // 
            this.txExtendedOW.Location = new System.Drawing.Point(144, 66);
            this.txExtendedOW.Name = "txExtendedOW";
            this.txExtendedOW.Size = new System.Drawing.Size(96, 24);
            this.txExtendedOW.TabIndex = 5;
            this.txExtendedOW.Text = "0";
            this.txExtendedOW.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Output Word:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Input Word:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txExtendedIW
            // 
            this.txExtendedIW.Location = new System.Drawing.Point(144, 35);
            this.txExtendedIW.Name = "txExtendedIW";
            this.txExtendedIW.Size = new System.Drawing.Size(96, 24);
            this.txExtendedIW.TabIndex = 2;
            this.txExtendedIW.Text = "0";
            this.txExtendedIW.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "IP Address:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txIPAddress
            // 
            this.txIPAddress.Location = new System.Drawing.Point(144, 34);
            this.txIPAddress.Name = "txIPAddress";
            this.txIPAddress.Size = new System.Drawing.Size(96, 24);
            this.txIPAddress.TabIndex = 2;
            this.txIPAddress.Text = "127.0.0.1";
            this.txIPAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tCycle
            // 
            this.tCycle.Tick += new System.EventHandler(this.TCycle_Tick);
            // 
            // ssStatus
            // 
            this.ssStatus.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.ssStatus.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsCmmtStatus,
            this.lbStatus});
            this.ssStatus.Location = new System.Drawing.Point(0, 539);
            this.ssStatus.Name = "ssStatus";
            this.ssStatus.Size = new System.Drawing.Size(822, 26);
            this.ssStatus.TabIndex = 5;
            this.ssStatus.Text = "statusStrip1";
            // 
            // lbStatus
            // 
            this.lbStatus.AutoSize = false;
            this.lbStatus.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lbStatus.Name = "lbStatus";
            this.lbStatus.Size = new System.Drawing.Size(200, 20);
            this.lbStatus.Text = "Status";
            this.lbStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(633, 15);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(142, 53);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MetaPlusLF", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(12, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(501, 46);
            this.label4.TabIndex = 5;
            this.label4.Text = "CMMT-xx-EP Modbus Control";
            // 
            // txRawIn
            // 
            this.txRawIn.Location = new System.Drawing.Point(6, 42);
            this.txRawIn.Multiline = true;
            this.txRawIn.Name = "txRawIn";
            this.txRawIn.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txRawIn.Size = new System.Drawing.Size(122, 316);
            this.txRawIn.TabIndex = 7;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.txVelocityOutputFG);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.txVelocityInputFG);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txPositionOutputFG);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.txPositionInputFG);
            this.groupBox3.Location = new System.Drawing.Point(21, 264);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(261, 161);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Factor Group";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 127);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 17);
            this.label7.TabIndex = 13;
            this.label7.Text = "Velocity Output:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txVelocityOutputFG
            // 
            this.txVelocityOutputFG.Location = new System.Drawing.Point(144, 124);
            this.txVelocityOutputFG.Name = "txVelocityOutputFG";
            this.txVelocityOutputFG.Size = new System.Drawing.Size(96, 24);
            this.txVelocityOutputFG.TabIndex = 12;
            this.txVelocityOutputFG.Text = "1";
            this.txVelocityOutputFG.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(28, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 17);
            this.label8.TabIndex = 11;
            this.label8.Text = "Velocity Input:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txVelocityInputFG
            // 
            this.txVelocityInputFG.Location = new System.Drawing.Point(144, 65);
            this.txVelocityInputFG.Name = "txVelocityInputFG";
            this.txVelocityInputFG.Size = new System.Drawing.Size(96, 24);
            this.txVelocityInputFG.TabIndex = 10;
            this.txVelocityInputFG.Text = "20000000";
            this.txVelocityInputFG.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 17);
            this.label6.TabIndex = 9;
            this.label6.Text = "Position Output:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txPositionOutputFG
            // 
            this.txPositionOutputFG.Location = new System.Drawing.Point(144, 94);
            this.txPositionOutputFG.Name = "txPositionOutputFG";
            this.txPositionOutputFG.Size = new System.Drawing.Size(96, 24);
            this.txPositionOutputFG.TabIndex = 8;
            this.txPositionOutputFG.Text = "1";
            this.txPositionOutputFG.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(28, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "Position Input:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txPositionInputFG
            // 
            this.txPositionInputFG.Location = new System.Drawing.Point(144, 35);
            this.txPositionInputFG.Name = "txPositionInputFG";
            this.txPositionInputFG.Size = new System.Drawing.Size(96, 24);
            this.txPositionInputFG.TabIndex = 6;
            this.txPositionInputFG.Text = "1000000";
            this.txPositionInputFG.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gbSetting
            // 
            this.gbSetting.Controls.Add(this.lbSettingPrev);
            this.gbSetting.Controls.Add(this.groupBox4);
            this.gbSetting.Controls.Add(this.lbSettingNext);
            this.gbSetting.Controls.Add(this.groupBox2);
            this.gbSetting.Controls.Add(this.groupBox3);
            this.gbSetting.Location = new System.Drawing.Point(835, 87);
            this.gbSetting.Name = "gbSetting";
            this.gbSetting.Size = new System.Drawing.Size(304, 444);
            this.gbSetting.TabIndex = 9;
            this.gbSetting.TabStop = false;
            this.gbSetting.Text = "Setting";
            this.gbSetting.Visible = false;
            // 
            // lbSettingPrev
            // 
            this.lbSettingPrev.AutoSize = true;
            this.lbSettingPrev.Location = new System.Drawing.Point(244, 21);
            this.lbSettingPrev.Name = "lbSettingPrev";
            this.lbSettingPrev.Size = new System.Drawing.Size(18, 17);
            this.lbSettingPrev.TabIndex = 35;
            this.lbSettingPrev.Text = "<<";
            this.lbSettingPrev.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbSettingPrev.Click += new System.EventHandler(this.LbSettingPrev_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.txPort);
            this.groupBox4.Controls.Add(this.txIPAddress);
            this.groupBox4.Location = new System.Drawing.Point(21, 34);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(261, 108);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Connection";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(90, 67);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 17);
            this.label9.TabIndex = 7;
            this.label9.Text = "Port:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txPort
            // 
            this.txPort.Location = new System.Drawing.Point(144, 64);
            this.txPort.Name = "txPort";
            this.txPort.Size = new System.Drawing.Size(96, 24);
            this.txPort.TabIndex = 6;
            this.txPort.Text = "502";
            this.txPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbSettingNext
            // 
            this.lbSettingNext.AutoSize = true;
            this.lbSettingNext.Location = new System.Drawing.Point(268, 21);
            this.lbSettingNext.Name = "lbSettingNext";
            this.lbSettingNext.Size = new System.Drawing.Size(18, 17);
            this.lbSettingNext.TabIndex = 34;
            this.lbSettingNext.Text = ">>";
            this.lbSettingNext.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbSettingNext.Click += new System.EventHandler(this.LbSettingNext_Click);
            // 
            // gbControl
            // 
            this.gbControl.Controls.Add(this.btJog1);
            this.gbControl.Controls.Add(this.btJog2);
            this.gbControl.Controls.Add(this.gbStatus);
            this.gbControl.Controls.Add(this.gbMode);
            this.gbControl.Controls.Add(this.btAck);
            this.gbControl.Controls.Add(this.btClear);
            this.gbControl.Controls.Add(this.btStop);
            this.gbControl.Controls.Add(this.btGo);
            this.gbControl.Controls.Add(this.cbEnableDrive);
            this.gbControl.Enabled = false;
            this.gbControl.Location = new System.Drawing.Point(20, 185);
            this.gbControl.Name = "gbControl";
            this.gbControl.Size = new System.Drawing.Size(465, 346);
            this.gbControl.TabIndex = 10;
            this.gbControl.TabStop = false;
            this.gbControl.Text = "Control";
            // 
            // cbEnableDrive
            // 
            this.cbEnableDrive.AutoSize = true;
            this.cbEnableDrive.Location = new System.Drawing.Point(14, 39);
            this.cbEnableDrive.Name = "cbEnableDrive";
            this.cbEnableDrive.Size = new System.Drawing.Size(109, 21);
            this.cbEnableDrive.TabIndex = 3;
            this.cbEnableDrive.Text = "Enable drive";
            this.cbEnableDrive.UseVisualStyleBackColor = true;
            // 
            // gbDebug
            // 
            this.gbDebug.Controls.Add(this.tabControl1);
            this.gbDebug.Controls.Add(this.lbDebugPrev);
            this.gbDebug.Controls.Add(this.lbDebugNext);
            this.gbDebug.Location = new System.Drawing.Point(1145, 87);
            this.gbDebug.Name = "gbDebug";
            this.gbDebug.Size = new System.Drawing.Size(304, 444);
            this.gbDebug.TabIndex = 9;
            this.gbDebug.TabStop = false;
            this.gbDebug.Text = "Monitor I/O";
            this.gbDebug.Visible = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpRaw);
            this.tabControl1.Controls.Add(this.tpSTW1);
            this.tabControl1.Controls.Add(this.tpZSW1);
            this.tabControl1.Controls.Add(this.tpPSTW1);
            this.tabControl1.Controls.Add(this.tpPZSW1);
            this.tabControl1.Controls.Add(this.tpPSTW2);
            this.tabControl1.Location = new System.Drawing.Point(20, 34);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(266, 391);
            this.tabControl1.TabIndex = 14;
            // 
            // tpRaw
            // 
            this.tpRaw.Controls.Add(this.txRawOut);
            this.tpRaw.Controls.Add(this.label18);
            this.tpRaw.Controls.Add(this.label17);
            this.tpRaw.Controls.Add(this.txRawIn);
            this.tpRaw.Location = new System.Drawing.Point(4, 26);
            this.tpRaw.Name = "tpRaw";
            this.tpRaw.Padding = new System.Windows.Forms.Padding(3);
            this.tpRaw.Size = new System.Drawing.Size(258, 361);
            this.tpRaw.TabIndex = 0;
            this.tpRaw.Text = "Raw";
            this.tpRaw.UseVisualStyleBackColor = true;
            // 
            // txRawOut
            // 
            this.txRawOut.Location = new System.Drawing.Point(134, 42);
            this.txRawOut.Multiline = true;
            this.txRawOut.Name = "txRawOut";
            this.txRawOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txRawOut.Size = new System.Drawing.Size(118, 316);
            this.txRawOut.TabIndex = 37;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(131, 19);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(57, 17);
            this.label18.TabIndex = 36;
            this.label18.Text = "Output:";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(15, 19);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(46, 17);
            this.label17.TabIndex = 34;
            this.label17.Text = "Input:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tpSTW1
            // 
            this.tpSTW1.Controls.Add(this.cbSTW1Write);
            this.tpSTW1.Controls.Add(this.cbSTW1_15);
            this.tpSTW1.Controls.Add(this.cbSTW1_14);
            this.tpSTW1.Controls.Add(this.cbSTW1_13);
            this.tpSTW1.Controls.Add(this.cbSTW1_12);
            this.tpSTW1.Controls.Add(this.cbSTW1_11);
            this.tpSTW1.Controls.Add(this.cbSTW1_10);
            this.tpSTW1.Controls.Add(this.cbSTW1_9);
            this.tpSTW1.Controls.Add(this.cbSTW1_8);
            this.tpSTW1.Controls.Add(this.cbSTW1_7);
            this.tpSTW1.Controls.Add(this.cbSTW1_6);
            this.tpSTW1.Controls.Add(this.cbSTW1_5);
            this.tpSTW1.Controls.Add(this.cbSTW1_4);
            this.tpSTW1.Controls.Add(this.cbSTW1_3);
            this.tpSTW1.Controls.Add(this.cbSTW1_2);
            this.tpSTW1.Controls.Add(this.cbSTW1_1);
            this.tpSTW1.Controls.Add(this.label22);
            this.tpSTW1.Controls.Add(this.cbSTW1_0);
            this.tpSTW1.Location = new System.Drawing.Point(4, 26);
            this.tpSTW1.Name = "tpSTW1";
            this.tpSTW1.Padding = new System.Windows.Forms.Padding(3);
            this.tpSTW1.Size = new System.Drawing.Size(258, 361);
            this.tpSTW1.TabIndex = 1;
            this.tpSTW1.Text = "STW1";
            this.tpSTW1.UseVisualStyleBackColor = true;
            // 
            // cbSTW1Write
            // 
            this.cbSTW1Write.AutoSize = true;
            this.cbSTW1Write.Location = new System.Drawing.Point(22, 8);
            this.cbSTW1Write.Name = "cbSTW1Write";
            this.cbSTW1Write.Size = new System.Drawing.Size(64, 21);
            this.cbSTW1Write.TabIndex = 69;
            this.cbSTW1Write.Text = "Write";
            this.cbSTW1Write.UseVisualStyleBackColor = true;
            // 
            // cbSTW1_15
            // 
            this.cbSTW1_15.AutoSize = true;
            this.cbSTW1_15.Location = new System.Drawing.Point(22, 328);
            this.cbSTW1_15.Name = "cbSTW1_15";
            this.cbSTW1_15.Size = new System.Drawing.Size(35, 21);
            this.cbSTW1_15.TabIndex = 68;
            this.cbSTW1_15.Text = "-";
            this.cbSTW1_15.UseVisualStyleBackColor = true;
            // 
            // cbSTW1_14
            // 
            this.cbSTW1_14.AutoSize = true;
            this.cbSTW1_14.Location = new System.Drawing.Point(22, 309);
            this.cbSTW1_14.Name = "cbSTW1_14";
            this.cbSTW1_14.Size = new System.Drawing.Size(35, 21);
            this.cbSTW1_14.TabIndex = 67;
            this.cbSTW1_14.Text = "-";
            this.cbSTW1_14.UseVisualStyleBackColor = true;
            // 
            // cbSTW1_13
            // 
            this.cbSTW1_13.AutoSize = true;
            this.cbSTW1_13.Location = new System.Drawing.Point(22, 290);
            this.cbSTW1_13.Name = "cbSTW1_13";
            this.cbSTW1_13.Size = new System.Drawing.Size(155, 21);
            this.cbSTW1_13.TabIndex = 66;
            this.cbSTW1_13.Text = "Start record change";
            this.cbSTW1_13.UseVisualStyleBackColor = true;
            // 
            // cbSTW1_12
            // 
            this.cbSTW1_12.AutoSize = true;
            this.cbSTW1_12.Location = new System.Drawing.Point(22, 271);
            this.cbSTW1_12.Name = "cbSTW1_12";
            this.cbSTW1_12.Size = new System.Drawing.Size(172, 21);
            this.cbSTW1_12.TabIndex = 65;
            this.cbSTW1_12.Text = "Release holding brake";
            this.cbSTW1_12.UseVisualStyleBackColor = true;
            // 
            // cbSTW1_11
            // 
            this.cbSTW1_11.AutoSize = true;
            this.cbSTW1_11.Location = new System.Drawing.Point(22, 252);
            this.cbSTW1_11.Name = "cbSTW1_11";
            this.cbSTW1_11.Size = new System.Drawing.Size(218, 21);
            this.cbSTW1_11.TabIndex = 64;
            this.cbSTW1_11.Text = "Invert setpoint / Start homing";
            this.cbSTW1_11.UseVisualStyleBackColor = true;
            // 
            // cbSTW1_10
            // 
            this.cbSTW1_10.AutoSize = true;
            this.cbSTW1_10.Location = new System.Drawing.Point(22, 233);
            this.cbSTW1_10.Name = "cbSTW1_10";
            this.cbSTW1_10.Size = new System.Drawing.Size(149, 21);
            this.cbSTW1_10.TabIndex = 63;
            this.cbSTW1_10.Text = "PLC master control";
            this.cbSTW1_10.UseVisualStyleBackColor = true;
            // 
            // cbSTW1_9
            // 
            this.cbSTW1_9.AutoSize = true;
            this.cbSTW1_9.Location = new System.Drawing.Point(22, 214);
            this.cbSTW1_9.Name = "cbSTW1_9";
            this.cbSTW1_9.Size = new System.Drawing.Size(86, 21);
            this.cbSTW1_9.TabIndex = 62;
            this.cbSTW1_9.Text = "Jogging -";
            this.cbSTW1_9.UseVisualStyleBackColor = true;
            // 
            // cbSTW1_8
            // 
            this.cbSTW1_8.AutoSize = true;
            this.cbSTW1_8.Location = new System.Drawing.Point(22, 195);
            this.cbSTW1_8.Name = "cbSTW1_8";
            this.cbSTW1_8.Size = new System.Drawing.Size(89, 21);
            this.cbSTW1_8.TabIndex = 61;
            this.cbSTW1_8.Text = "Jogging +";
            this.cbSTW1_8.UseVisualStyleBackColor = true;
            // 
            // cbSTW1_7
            // 
            this.cbSTW1_7.AutoSize = true;
            this.cbSTW1_7.Location = new System.Drawing.Point(22, 175);
            this.cbSTW1_7.Name = "cbSTW1_7";
            this.cbSTW1_7.Size = new System.Drawing.Size(194, 21);
            this.cbSTW1_7.TabIndex = 52;
            this.cbSTW1_7.Text = "Acknowledge malfunction";
            this.cbSTW1_7.UseVisualStyleBackColor = true;
            // 
            // cbSTW1_6
            // 
            this.cbSTW1_6.AutoSize = true;
            this.cbSTW1_6.Location = new System.Drawing.Point(22, 156);
            this.cbSTW1_6.Name = "cbSTW1_6";
            this.cbSTW1_6.Size = new System.Drawing.Size(215, 21);
            this.cbSTW1_6.TabIndex = 50;
            this.cbSTW1_6.Text = "Speed set / Activate pos task";
            this.cbSTW1_6.UseVisualStyleBackColor = true;
            // 
            // cbSTW1_5
            // 
            this.cbSTW1_5.AutoSize = true;
            this.cbSTW1_5.Location = new System.Drawing.Point(22, 137);
            this.cbSTW1_5.Name = "cbSTW1_5";
            this.cbSTW1_5.Size = new System.Drawing.Size(224, 21);
            this.cbSTW1_5.TabIndex = 48;
            this.cbSTW1_5.Text = "Start ramp / Intermediate stop";
            this.cbSTW1_5.UseVisualStyleBackColor = true;
            // 
            // cbSTW1_4
            // 
            this.cbSTW1_4.AutoSize = true;
            this.cbSTW1_4.Location = new System.Drawing.Point(22, 118);
            this.cbSTW1_4.Name = "cbSTW1_4";
            this.cbSTW1_4.Size = new System.Drawing.Size(204, 21);
            this.cbSTW1_4.TabIndex = 46;
            this.cbSTW1_4.Text = "Ramp gen / Reject pos task";
            this.cbSTW1_4.UseVisualStyleBackColor = true;
            // 
            // cbSTW1_3
            // 
            this.cbSTW1_3.AutoSize = true;
            this.cbSTW1_3.Location = new System.Drawing.Point(22, 99);
            this.cbSTW1_3.Name = "cbSTW1_3";
            this.cbSTW1_3.Size = new System.Drawing.Size(139, 21);
            this.cbSTW1_3.TabIndex = 44;
            this.cbSTW1_3.Text = "Enable operation";
            this.cbSTW1_3.UseVisualStyleBackColor = true;
            // 
            // cbSTW1_2
            // 
            this.cbSTW1_2.AutoSize = true;
            this.cbSTW1_2.Location = new System.Drawing.Point(22, 80);
            this.cbSTW1_2.Name = "cbSTW1_2";
            this.cbSTW1_2.Size = new System.Drawing.Size(89, 21);
            this.cbSTW1_2.TabIndex = 42;
            this.cbSTW1_2.Text = "Fast Stop";
            this.cbSTW1_2.UseVisualStyleBackColor = true;
            // 
            // cbSTW1_1
            // 
            this.cbSTW1_1.AutoSize = true;
            this.cbSTW1_1.Location = new System.Drawing.Point(22, 61);
            this.cbSTW1_1.Name = "cbSTW1_1";
            this.cbSTW1_1.Size = new System.Drawing.Size(101, 21);
            this.cbSTW1_1.TabIndex = 40;
            this.cbSTW1_1.Text = "Drive coast";
            this.cbSTW1_1.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(195, 8);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(52, 17);
            this.label22.TabIndex = 38;
            this.label22.Text = "Output";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbSTW1_0
            // 
            this.cbSTW1_0.AutoSize = true;
            this.cbSTW1_0.Location = new System.Drawing.Point(22, 42);
            this.cbSTW1_0.Name = "cbSTW1_0";
            this.cbSTW1_0.Size = new System.Drawing.Size(160, 21);
            this.cbSTW1_0.TabIndex = 0;
            this.cbSTW1_0.Text = "Output stage enable";
            this.cbSTW1_0.UseVisualStyleBackColor = true;
            // 
            // tpZSW1
            // 
            this.tpZSW1.Controls.Add(this.cbZSW1_9);
            this.tpZSW1.Controls.Add(this.cbZSW1_15);
            this.tpZSW1.Controls.Add(this.cbZSW1_14);
            this.tpZSW1.Controls.Add(this.cbZSW1_13);
            this.tpZSW1.Controls.Add(this.cbZSW1_12);
            this.tpZSW1.Controls.Add(this.cbZSW1_10);
            this.tpZSW1.Controls.Add(this.cbZSW1_11);
            this.tpZSW1.Controls.Add(this.cbZSW1_8);
            this.tpZSW1.Controls.Add(this.cbZSW1_7);
            this.tpZSW1.Controls.Add(this.cbZSW1_6);
            this.tpZSW1.Controls.Add(this.cbZSW1_5);
            this.tpZSW1.Controls.Add(this.cbZSW1_4);
            this.tpZSW1.Controls.Add(this.cbZSW1_3);
            this.tpZSW1.Controls.Add(this.cbZSW1_2);
            this.tpZSW1.Controls.Add(this.cbZSW1_1);
            this.tpZSW1.Controls.Add(this.cbZSW1_0);
            this.tpZSW1.Controls.Add(this.label23);
            this.tpZSW1.Location = new System.Drawing.Point(4, 26);
            this.tpZSW1.Name = "tpZSW1";
            this.tpZSW1.Size = new System.Drawing.Size(258, 361);
            this.tpZSW1.TabIndex = 2;
            this.tpZSW1.Text = "ZSW1";
            this.tpZSW1.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_9
            // 
            this.cbZSW1_9.AutoSize = true;
            this.cbZSW1_9.Location = new System.Drawing.Point(22, 214);
            this.cbZSW1_9.Name = "cbZSW1_9";
            this.cbZSW1_9.Size = new System.Drawing.Size(124, 21);
            this.cbZSW1_9.TabIndex = 84;
            this.cbZSW1_9.Text = "Guide required";
            this.cbZSW1_9.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_15
            // 
            this.cbZSW1_15.AutoSize = true;
            this.cbZSW1_15.Location = new System.Drawing.Point(22, 328);
            this.cbZSW1_15.Name = "cbZSW1_15";
            this.cbZSW1_15.Size = new System.Drawing.Size(228, 21);
            this.cbZSW1_15.TabIndex = 83;
            this.cbZSW1_15.Text = "No temp warning / decelerated";
            this.cbZSW1_15.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_14
            // 
            this.cbZSW1_14.AutoSize = true;
            this.cbZSW1_14.Location = new System.Drawing.Point(22, 309);
            this.cbZSW1_14.Name = "cbZSW1_14";
            this.cbZSW1_14.Size = new System.Drawing.Size(217, 21);
            this.cbZSW1_14.TabIndex = 82;
            this.cbZSW1_14.Text = "Motor direction / accelerated";
            this.cbZSW1_14.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_13
            // 
            this.cbZSW1_13.AutoSize = true;
            this.cbZSW1_13.Location = new System.Drawing.Point(22, 290);
            this.cbZSW1_13.Name = "cbZSW1_13";
            this.cbZSW1_13.Size = new System.Drawing.Size(222, 21);
            this.cbZSW1_13.TabIndex = 81;
            this.cbZSW1_13.Text = "No overheat / Drive stationary";
            this.cbZSW1_13.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_12
            // 
            this.cbZSW1_12.AutoSize = true;
            this.cbZSW1_12.Location = new System.Drawing.Point(22, 271);
            this.cbZSW1_12.Name = "cbZSW1_12";
            this.cbZSW1_12.Size = new System.Drawing.Size(182, 21);
            this.cbZSW1_12.TabIndex = 80;
            this.cbZSW1_12.Text = "Positioning task actived";
            this.cbZSW1_12.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_10
            // 
            this.cbZSW1_10.AutoSize = true;
            this.cbZSW1_10.Location = new System.Drawing.Point(22, 233);
            this.cbZSW1_10.Name = "cbZSW1_10";
            this.cbZSW1_10.Size = new System.Drawing.Size(184, 21);
            this.cbZSW1_10.TabIndex = 79;
            this.cbZSW1_10.Text = "Target vel / pos reached";
            this.cbZSW1_10.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_11
            // 
            this.cbZSW1_11.AutoSize = true;
            this.cbZSW1_11.Location = new System.Drawing.Point(22, 252);
            this.cbZSW1_11.Name = "cbZSW1_11";
            this.cbZSW1_11.Size = new System.Drawing.Size(224, 21);
            this.cbZSW1_11.TabIndex = 78;
            this.cbZSW1_11.Text = "IMP limit not reached / Homed";
            this.cbZSW1_11.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_8
            // 
            this.cbZSW1_8.AutoSize = true;
            this.cbZSW1_8.Location = new System.Drawing.Point(22, 195);
            this.cbZSW1_8.Name = "cbZSW1_8";
            this.cbZSW1_8.Size = new System.Drawing.Size(202, 21);
            this.cbZSW1_8.TabIndex = 77;
            this.cbZSW1_8.Text = "Velocity / Position in range";
            this.cbZSW1_8.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_7
            // 
            this.cbZSW1_7.AutoSize = true;
            this.cbZSW1_7.Location = new System.Drawing.Point(22, 175);
            this.cbZSW1_7.Name = "cbZSW1_7";
            this.cbZSW1_7.Size = new System.Drawing.Size(141, 21);
            this.cbZSW1_7.TabIndex = 76;
            this.cbZSW1_7.Text = "Warning effective";
            this.cbZSW1_7.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_6
            // 
            this.cbZSW1_6.AutoSize = true;
            this.cbZSW1_6.Location = new System.Drawing.Point(22, 156);
            this.cbZSW1_6.Name = "cbZSW1_6";
            this.cbZSW1_6.Size = new System.Drawing.Size(162, 21);
            this.cbZSW1_6.TabIndex = 75;
            this.cbZSW1_6.Text = "Switch on lock active";
            this.cbZSW1_6.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_5
            // 
            this.cbZSW1_5.AutoSize = true;
            this.cbZSW1_5.Location = new System.Drawing.Point(22, 137);
            this.cbZSW1_5.Name = "cbZSW1_5";
            this.cbZSW1_5.Size = new System.Drawing.Size(161, 21);
            this.cbZSW1_5.TabIndex = 74;
            this.cbZSW1_5.Text = "Fast stop active (NC)";
            this.cbZSW1_5.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_4
            // 
            this.cbZSW1_4.AutoSize = true;
            this.cbZSW1_4.Location = new System.Drawing.Point(22, 118);
            this.cbZSW1_4.Name = "cbZSW1_4";
            this.cbZSW1_4.Size = new System.Drawing.Size(159, 21);
            this.cbZSW1_4.TabIndex = 73;
            this.cbZSW1_4.Text = "Coasting active (NC)";
            this.cbZSW1_4.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_3
            // 
            this.cbZSW1_3.AutoSize = true;
            this.cbZSW1_3.Location = new System.Drawing.Point(22, 99);
            this.cbZSW1_3.Name = "cbZSW1_3";
            this.cbZSW1_3.Size = new System.Drawing.Size(164, 21);
            this.cbZSW1_3.TabIndex = 72;
            this.cbZSW1_3.Text = "Mulfunction effective";
            this.cbZSW1_3.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_2
            // 
            this.cbZSW1_2.AutoSize = true;
            this.cbZSW1_2.Location = new System.Drawing.Point(22, 80);
            this.cbZSW1_2.Name = "cbZSW1_2";
            this.cbZSW1_2.Size = new System.Drawing.Size(149, 21);
            this.cbZSW1_2.TabIndex = 71;
            this.cbZSW1_2.Text = "Operation enabled";
            this.cbZSW1_2.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_1
            // 
            this.cbZSW1_1.AutoSize = true;
            this.cbZSW1_1.Location = new System.Drawing.Point(22, 61);
            this.cbZSW1_1.Name = "cbZSW1_1";
            this.cbZSW1_1.Size = new System.Drawing.Size(155, 21);
            this.cbZSW1_1.TabIndex = 70;
            this.cbZSW1_1.Text = "Ready for operation";
            this.cbZSW1_1.UseVisualStyleBackColor = true;
            // 
            // cbZSW1_0
            // 
            this.cbZSW1_0.AutoSize = true;
            this.cbZSW1_0.Location = new System.Drawing.Point(22, 42);
            this.cbZSW1_0.Name = "cbZSW1_0";
            this.cbZSW1_0.Size = new System.Drawing.Size(184, 21);
            this.cbZSW1_0.TabIndex = 69;
            this.cbZSW1_0.Text = "Ready to be switched on";
            this.cbZSW1_0.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(197, 8);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 17);
            this.label23.TabIndex = 38;
            this.label23.Text = "Input";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tpPSTW1
            // 
            this.tpPSTW1.Controls.Add(this.cbPSTW1Write);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_15);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_14);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_13);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_12);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_11);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_10);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_9);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_8);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_7);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_6);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_5);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_4);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_3);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_2);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_1);
            this.tpPSTW1.Controls.Add(this.cbPSTW1_0);
            this.tpPSTW1.Controls.Add(this.label24);
            this.tpPSTW1.Location = new System.Drawing.Point(4, 26);
            this.tpPSTW1.Name = "tpPSTW1";
            this.tpPSTW1.Size = new System.Drawing.Size(258, 361);
            this.tpPSTW1.TabIndex = 3;
            this.tpPSTW1.Text = "PSTW1";
            this.tpPSTW1.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1Write
            // 
            this.cbPSTW1Write.AutoSize = true;
            this.cbPSTW1Write.Location = new System.Drawing.Point(22, 8);
            this.cbPSTW1Write.Name = "cbPSTW1Write";
            this.cbPSTW1Write.Size = new System.Drawing.Size(64, 21);
            this.cbPSTW1Write.TabIndex = 85;
            this.cbPSTW1Write.Text = "Write";
            this.cbPSTW1Write.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_15
            // 
            this.cbPSTW1_15.AutoSize = true;
            this.cbPSTW1_15.Location = new System.Drawing.Point(22, 328);
            this.cbPSTW1_15.Name = "cbPSTW1_15";
            this.cbPSTW1_15.Size = new System.Drawing.Size(117, 21);
            this.cbPSTW1_15.TabIndex = 84;
            this.cbPSTW1_15.Text = "MDI selection";
            this.cbPSTW1_15.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_14
            // 
            this.cbPSTW1_14.AutoSize = true;
            this.cbPSTW1_14.Location = new System.Drawing.Point(22, 309);
            this.cbPSTW1_14.Name = "cbPSTW1_14";
            this.cbPSTW1_14.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW1_14.TabIndex = 83;
            this.cbPSTW1_14.Text = "-";
            this.cbPSTW1_14.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_13
            // 
            this.cbPSTW1_13.AutoSize = true;
            this.cbPSTW1_13.Location = new System.Drawing.Point(22, 290);
            this.cbPSTW1_13.Name = "cbPSTW1_13";
            this.cbPSTW1_13.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW1_13.TabIndex = 82;
            this.cbPSTW1_13.Text = "-";
            this.cbPSTW1_13.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_12
            // 
            this.cbPSTW1_12.AutoSize = true;
            this.cbPSTW1_12.Location = new System.Drawing.Point(22, 271);
            this.cbPSTW1_12.Name = "cbPSTW1_12";
            this.cbPSTW1_12.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW1_12.TabIndex = 81;
            this.cbPSTW1_12.Text = "-";
            this.cbPSTW1_12.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_11
            // 
            this.cbPSTW1_11.AutoSize = true;
            this.cbPSTW1_11.Location = new System.Drawing.Point(22, 252);
            this.cbPSTW1_11.Name = "cbPSTW1_11";
            this.cbPSTW1_11.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW1_11.TabIndex = 80;
            this.cbPSTW1_11.Text = "-";
            this.cbPSTW1_11.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_10
            // 
            this.cbPSTW1_10.AutoSize = true;
            this.cbPSTW1_10.Location = new System.Drawing.Point(22, 233);
            this.cbPSTW1_10.Name = "cbPSTW1_10";
            this.cbPSTW1_10.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW1_10.TabIndex = 79;
            this.cbPSTW1_10.Text = "-";
            this.cbPSTW1_10.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_9
            // 
            this.cbPSTW1_9.AutoSize = true;
            this.cbPSTW1_9.Location = new System.Drawing.Point(22, 214);
            this.cbPSTW1_9.Name = "cbPSTW1_9";
            this.cbPSTW1_9.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW1_9.TabIndex = 78;
            this.cbPSTW1_9.Text = "-";
            this.cbPSTW1_9.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_8
            // 
            this.cbPSTW1_8.AutoSize = true;
            this.cbPSTW1_8.Location = new System.Drawing.Point(22, 195);
            this.cbPSTW1_8.Name = "cbPSTW1_8";
            this.cbPSTW1_8.Size = new System.Drawing.Size(184, 21);
            this.cbPSTW1_8.TabIndex = 77;
            this.cbPSTW1_8.Text = "Relative / Absolute (=1)";
            this.cbPSTW1_8.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_7
            // 
            this.cbPSTW1_7.AutoSize = true;
            this.cbPSTW1_7.Location = new System.Drawing.Point(22, 175);
            this.cbPSTW1_7.Name = "cbPSTW1_7";
            this.cbPSTW1_7.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW1_7.TabIndex = 76;
            this.cbPSTW1_7.Text = "-";
            this.cbPSTW1_7.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_6
            // 
            this.cbPSTW1_6.AutoSize = true;
            this.cbPSTW1_6.Location = new System.Drawing.Point(22, 156);
            this.cbPSTW1_6.Name = "cbPSTW1_6";
            this.cbPSTW1_6.Size = new System.Drawing.Size(177, 21);
            this.cbPSTW1_6.TabIndex = 75;
            this.cbPSTW1_6.Text = "Positioning record bit 6";
            this.cbPSTW1_6.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_5
            // 
            this.cbPSTW1_5.AutoSize = true;
            this.cbPSTW1_5.Location = new System.Drawing.Point(22, 137);
            this.cbPSTW1_5.Name = "cbPSTW1_5";
            this.cbPSTW1_5.Size = new System.Drawing.Size(177, 21);
            this.cbPSTW1_5.TabIndex = 74;
            this.cbPSTW1_5.Text = "Positioning record bit 5";
            this.cbPSTW1_5.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_4
            // 
            this.cbPSTW1_4.AutoSize = true;
            this.cbPSTW1_4.Location = new System.Drawing.Point(22, 118);
            this.cbPSTW1_4.Name = "cbPSTW1_4";
            this.cbPSTW1_4.Size = new System.Drawing.Size(177, 21);
            this.cbPSTW1_4.TabIndex = 73;
            this.cbPSTW1_4.Text = "Positioning record bit 4";
            this.cbPSTW1_4.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_3
            // 
            this.cbPSTW1_3.AutoSize = true;
            this.cbPSTW1_3.Location = new System.Drawing.Point(22, 99);
            this.cbPSTW1_3.Name = "cbPSTW1_3";
            this.cbPSTW1_3.Size = new System.Drawing.Size(177, 21);
            this.cbPSTW1_3.TabIndex = 72;
            this.cbPSTW1_3.Text = "Positioning record bit 3";
            this.cbPSTW1_3.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_2
            // 
            this.cbPSTW1_2.AutoSize = true;
            this.cbPSTW1_2.Location = new System.Drawing.Point(22, 80);
            this.cbPSTW1_2.Name = "cbPSTW1_2";
            this.cbPSTW1_2.Size = new System.Drawing.Size(177, 21);
            this.cbPSTW1_2.TabIndex = 71;
            this.cbPSTW1_2.Text = "Positioning record bit 2";
            this.cbPSTW1_2.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_1
            // 
            this.cbPSTW1_1.AutoSize = true;
            this.cbPSTW1_1.Location = new System.Drawing.Point(22, 61);
            this.cbPSTW1_1.Name = "cbPSTW1_1";
            this.cbPSTW1_1.Size = new System.Drawing.Size(177, 21);
            this.cbPSTW1_1.TabIndex = 70;
            this.cbPSTW1_1.Text = "Positioning record bit 1";
            this.cbPSTW1_1.UseVisualStyleBackColor = true;
            // 
            // cbPSTW1_0
            // 
            this.cbPSTW1_0.AutoSize = true;
            this.cbPSTW1_0.Location = new System.Drawing.Point(22, 42);
            this.cbPSTW1_0.Name = "cbPSTW1_0";
            this.cbPSTW1_0.Size = new System.Drawing.Size(177, 21);
            this.cbPSTW1_0.TabIndex = 69;
            this.cbPSTW1_0.Text = "Positioning record bit 0";
            this.cbPSTW1_0.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(195, 8);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(52, 17);
            this.label24.TabIndex = 39;
            this.label24.Text = "Output";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tpPZSW1
            // 
            this.tpPZSW1.Controls.Add(this.cbPZSW1_15);
            this.tpPZSW1.Controls.Add(this.cbPZSW1_14);
            this.tpPZSW1.Controls.Add(this.cbPZSW1_13);
            this.tpPZSW1.Controls.Add(this.cbPZSW1_12);
            this.tpPZSW1.Controls.Add(this.cbPZSW1_11);
            this.tpPZSW1.Controls.Add(this.cbPZSW1_10);
            this.tpPZSW1.Controls.Add(this.cbPZSW1_9);
            this.tpPZSW1.Controls.Add(this.cbPZSW1_8);
            this.tpPZSW1.Controls.Add(this.cbPZSW1_7);
            this.tpPZSW1.Controls.Add(this.cbPZSW1_6);
            this.tpPZSW1.Controls.Add(this.cbPZSW1_5);
            this.tpPZSW1.Controls.Add(this.cbPZSW1_4);
            this.tpPZSW1.Controls.Add(this.cbPZSW1_3);
            this.tpPZSW1.Controls.Add(this.cbPZSW1_2);
            this.tpPZSW1.Controls.Add(this.cbPZSW1_1);
            this.tpPZSW1.Controls.Add(this.cbPZSW1_0);
            this.tpPZSW1.Controls.Add(this.label26);
            this.tpPZSW1.Location = new System.Drawing.Point(4, 26);
            this.tpPZSW1.Name = "tpPZSW1";
            this.tpPZSW1.Size = new System.Drawing.Size(258, 361);
            this.tpPZSW1.TabIndex = 4;
            this.tpPZSW1.Text = "PZSW1";
            this.tpPZSW1.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_15
            // 
            this.cbPZSW1_15.AutoSize = true;
            this.cbPZSW1_15.Location = new System.Drawing.Point(22, 328);
            this.cbPZSW1_15.Name = "cbPZSW1_15";
            this.cbPZSW1_15.Size = new System.Drawing.Size(97, 21);
            this.cbPZSW1_15.TabIndex = 84;
            this.cbPZSW1_15.Text = "MDI active";
            this.cbPZSW1_15.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_14
            // 
            this.cbPZSW1_14.AutoSize = true;
            this.cbPZSW1_14.Location = new System.Drawing.Point(22, 309);
            this.cbPZSW1_14.Name = "cbPZSW1_14";
            this.cbPZSW1_14.Size = new System.Drawing.Size(35, 21);
            this.cbPZSW1_14.TabIndex = 83;
            this.cbPZSW1_14.Text = "-";
            this.cbPZSW1_14.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_13
            // 
            this.cbPZSW1_13.AutoSize = true;
            this.cbPZSW1_13.Location = new System.Drawing.Point(22, 290);
            this.cbPZSW1_13.Name = "cbPZSW1_13";
            this.cbPZSW1_13.Size = new System.Drawing.Size(188, 21);
            this.cbPZSW1_13.TabIndex = 82;
            this.cbPZSW1_13.Text = "Positioning record active";
            this.cbPZSW1_13.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_12
            // 
            this.cbPZSW1_12.AutoSize = true;
            this.cbPZSW1_12.Location = new System.Drawing.Point(22, 271);
            this.cbPZSW1_12.Name = "cbPZSW1_12";
            this.cbPZSW1_12.Size = new System.Drawing.Size(35, 21);
            this.cbPZSW1_12.TabIndex = 81;
            this.cbPZSW1_12.Text = "-";
            this.cbPZSW1_12.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_11
            // 
            this.cbPZSW1_11.AutoSize = true;
            this.cbPZSW1_11.Location = new System.Drawing.Point(22, 252);
            this.cbPZSW1_11.Name = "cbPZSW1_11";
            this.cbPZSW1_11.Size = new System.Drawing.Size(122, 21);
            this.cbPZSW1_11.TabIndex = 80;
            this.cbPZSW1_11.Text = "Homing active";
            this.cbPZSW1_11.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_10
            // 
            this.cbPZSW1_10.AutoSize = true;
            this.cbPZSW1_10.Location = new System.Drawing.Point(22, 233);
            this.cbPZSW1_10.Name = "cbPZSW1_10";
            this.cbPZSW1_10.Size = new System.Drawing.Size(120, 21);
            this.cbPZSW1_10.TabIndex = 79;
            this.cbPZSW1_10.Text = "Jogging active";
            this.cbPZSW1_10.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_9
            // 
            this.cbPZSW1_9.AutoSize = true;
            this.cbPZSW1_9.Location = new System.Drawing.Point(22, 214);
            this.cbPZSW1_9.Name = "cbPZSW1_9";
            this.cbPZSW1_9.Size = new System.Drawing.Size(212, 21);
            this.cbPZSW1_9.TabIndex = 78;
            this.cbPZSW1_9.Text = "Positive limit switch reached";
            this.cbPZSW1_9.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_8
            // 
            this.cbPZSW1_8.AutoSize = true;
            this.cbPZSW1_8.Location = new System.Drawing.Point(22, 195);
            this.cbPZSW1_8.Name = "cbPZSW1_8";
            this.cbPZSW1_8.Size = new System.Drawing.Size(219, 21);
            this.cbPZSW1_8.TabIndex = 77;
            this.cbPZSW1_8.Text = "Negative limit switch reached";
            this.cbPZSW1_8.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_7
            // 
            this.cbPZSW1_7.AutoSize = true;
            this.cbPZSW1_7.Location = new System.Drawing.Point(22, 175);
            this.cbPZSW1_7.Name = "cbPZSW1_7";
            this.cbPZSW1_7.Size = new System.Drawing.Size(35, 21);
            this.cbPZSW1_7.TabIndex = 76;
            this.cbPZSW1_7.Text = "-";
            this.cbPZSW1_7.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_6
            // 
            this.cbPZSW1_6.AutoSize = true;
            this.cbPZSW1_6.Location = new System.Drawing.Point(22, 156);
            this.cbPZSW1_6.Name = "cbPZSW1_6";
            this.cbPZSW1_6.Size = new System.Drawing.Size(223, 21);
            this.cbPZSW1_6.TabIndex = 75;
            this.cbPZSW1_6.Text = "Active positioning record bit  6";
            this.cbPZSW1_6.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_5
            // 
            this.cbPZSW1_5.AutoSize = true;
            this.cbPZSW1_5.Location = new System.Drawing.Point(22, 137);
            this.cbPZSW1_5.Name = "cbPZSW1_5";
            this.cbPZSW1_5.Size = new System.Drawing.Size(223, 21);
            this.cbPZSW1_5.TabIndex = 74;
            this.cbPZSW1_5.Text = "Active positioning record bit  5";
            this.cbPZSW1_5.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_4
            // 
            this.cbPZSW1_4.AutoSize = true;
            this.cbPZSW1_4.Location = new System.Drawing.Point(22, 118);
            this.cbPZSW1_4.Name = "cbPZSW1_4";
            this.cbPZSW1_4.Size = new System.Drawing.Size(223, 21);
            this.cbPZSW1_4.TabIndex = 73;
            this.cbPZSW1_4.Text = "Active positioning record bit  4";
            this.cbPZSW1_4.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_3
            // 
            this.cbPZSW1_3.AutoSize = true;
            this.cbPZSW1_3.Location = new System.Drawing.Point(22, 99);
            this.cbPZSW1_3.Name = "cbPZSW1_3";
            this.cbPZSW1_3.Size = new System.Drawing.Size(223, 21);
            this.cbPZSW1_3.TabIndex = 72;
            this.cbPZSW1_3.Text = "Active positioning record bit  3";
            this.cbPZSW1_3.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_2
            // 
            this.cbPZSW1_2.AutoSize = true;
            this.cbPZSW1_2.Location = new System.Drawing.Point(22, 80);
            this.cbPZSW1_2.Name = "cbPZSW1_2";
            this.cbPZSW1_2.Size = new System.Drawing.Size(223, 21);
            this.cbPZSW1_2.TabIndex = 71;
            this.cbPZSW1_2.Text = "Active positioning record bit  2";
            this.cbPZSW1_2.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_1
            // 
            this.cbPZSW1_1.AutoSize = true;
            this.cbPZSW1_1.Location = new System.Drawing.Point(22, 61);
            this.cbPZSW1_1.Name = "cbPZSW1_1";
            this.cbPZSW1_1.Size = new System.Drawing.Size(223, 21);
            this.cbPZSW1_1.TabIndex = 70;
            this.cbPZSW1_1.Text = "Active positioning record bit  1";
            this.cbPZSW1_1.UseVisualStyleBackColor = true;
            // 
            // cbPZSW1_0
            // 
            this.cbPZSW1_0.AutoSize = true;
            this.cbPZSW1_0.Location = new System.Drawing.Point(22, 42);
            this.cbPZSW1_0.Name = "cbPZSW1_0";
            this.cbPZSW1_0.Size = new System.Drawing.Size(223, 21);
            this.cbPZSW1_0.TabIndex = 69;
            this.cbPZSW1_0.Text = "Active positioning record bit  0";
            this.cbPZSW1_0.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(197, 8);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 17);
            this.label26.TabIndex = 39;
            this.label26.Text = "Input";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tpPSTW2
            // 
            this.tpPSTW2.Controls.Add(this.cbPSTW2Write);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_15);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_14);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_13);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_12);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_11);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_10);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_9);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_8);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_7);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_6);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_5);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_4);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_3);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_2);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_1);
            this.tpPSTW2.Controls.Add(this.cbPSTW2_0);
            this.tpPSTW2.Controls.Add(this.label25);
            this.tpPSTW2.Location = new System.Drawing.Point(4, 26);
            this.tpPSTW2.Name = "tpPSTW2";
            this.tpPSTW2.Size = new System.Drawing.Size(258, 361);
            this.tpPSTW2.TabIndex = 5;
            this.tpPSTW2.Text = "PSTW2";
            this.tpPSTW2.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2Write
            // 
            this.cbPSTW2Write.AutoSize = true;
            this.cbPSTW2Write.Location = new System.Drawing.Point(22, 8);
            this.cbPSTW2Write.Name = "cbPSTW2Write";
            this.cbPSTW2Write.Size = new System.Drawing.Size(64, 21);
            this.cbPSTW2Write.TabIndex = 85;
            this.cbPSTW2Write.Text = "Write";
            this.cbPSTW2Write.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_15
            // 
            this.cbPSTW2_15.AutoSize = true;
            this.cbPSTW2_15.Location = new System.Drawing.Point(22, 328);
            this.cbPSTW2_15.Name = "cbPSTW2_15";
            this.cbPSTW2_15.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW2_15.TabIndex = 84;
            this.cbPSTW2_15.Text = "-";
            this.cbPSTW2_15.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_14
            // 
            this.cbPSTW2_14.AutoSize = true;
            this.cbPSTW2_14.Location = new System.Drawing.Point(22, 309);
            this.cbPSTW2_14.Name = "cbPSTW2_14";
            this.cbPSTW2_14.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW2_14.TabIndex = 83;
            this.cbPSTW2_14.Text = "-";
            this.cbPSTW2_14.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_13
            // 
            this.cbPSTW2_13.AutoSize = true;
            this.cbPSTW2_13.Location = new System.Drawing.Point(22, 290);
            this.cbPSTW2_13.Name = "cbPSTW2_13";
            this.cbPSTW2_13.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW2_13.TabIndex = 82;
            this.cbPSTW2_13.Text = "-";
            this.cbPSTW2_13.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_12
            // 
            this.cbPSTW2_12.AutoSize = true;
            this.cbPSTW2_12.Location = new System.Drawing.Point(22, 271);
            this.cbPSTW2_12.Name = "cbPSTW2_12";
            this.cbPSTW2_12.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW2_12.TabIndex = 81;
            this.cbPSTW2_12.Text = "-";
            this.cbPSTW2_12.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_11
            // 
            this.cbPSTW2_11.AutoSize = true;
            this.cbPSTW2_11.Location = new System.Drawing.Point(22, 252);
            this.cbPSTW2_11.Name = "cbPSTW2_11";
            this.cbPSTW2_11.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW2_11.TabIndex = 80;
            this.cbPSTW2_11.Text = "-";
            this.cbPSTW2_11.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_10
            // 
            this.cbPSTW2_10.AutoSize = true;
            this.cbPSTW2_10.Location = new System.Drawing.Point(22, 233);
            this.cbPSTW2_10.Name = "cbPSTW2_10";
            this.cbPSTW2_10.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW2_10.TabIndex = 79;
            this.cbPSTW2_10.Text = "-";
            this.cbPSTW2_10.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_9
            // 
            this.cbPSTW2_9.AutoSize = true;
            this.cbPSTW2_9.Location = new System.Drawing.Point(22, 214);
            this.cbPSTW2_9.Name = "cbPSTW2_9";
            this.cbPSTW2_9.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW2_9.TabIndex = 78;
            this.cbPSTW2_9.Text = "-";
            this.cbPSTW2_9.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_8
            // 
            this.cbPSTW2_8.AutoSize = true;
            this.cbPSTW2_8.Location = new System.Drawing.Point(22, 195);
            this.cbPSTW2_8.Name = "cbPSTW2_8";
            this.cbPSTW2_8.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW2_8.TabIndex = 77;
            this.cbPSTW2_8.Text = "-";
            this.cbPSTW2_8.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_7
            // 
            this.cbPSTW2_7.AutoSize = true;
            this.cbPSTW2_7.Location = new System.Drawing.Point(22, 175);
            this.cbPSTW2_7.Name = "cbPSTW2_7";
            this.cbPSTW2_7.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW2_7.TabIndex = 76;
            this.cbPSTW2_7.Text = "-";
            this.cbPSTW2_7.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_6
            // 
            this.cbPSTW2_6.AutoSize = true;
            this.cbPSTW2_6.Location = new System.Drawing.Point(22, 156);
            this.cbPSTW2_6.Name = "cbPSTW2_6";
            this.cbPSTW2_6.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW2_6.TabIndex = 75;
            this.cbPSTW2_6.Text = "-";
            this.cbPSTW2_6.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_5
            // 
            this.cbPSTW2_5.AutoSize = true;
            this.cbPSTW2_5.Location = new System.Drawing.Point(22, 137);
            this.cbPSTW2_5.Name = "cbPSTW2_5";
            this.cbPSTW2_5.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW2_5.TabIndex = 74;
            this.cbPSTW2_5.Text = "-";
            this.cbPSTW2_5.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_4
            // 
            this.cbPSTW2_4.AutoSize = true;
            this.cbPSTW2_4.Location = new System.Drawing.Point(22, 118);
            this.cbPSTW2_4.Name = "cbPSTW2_4";
            this.cbPSTW2_4.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW2_4.TabIndex = 73;
            this.cbPSTW2_4.Text = "-";
            this.cbPSTW2_4.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_3
            // 
            this.cbPSTW2_3.AutoSize = true;
            this.cbPSTW2_3.Location = new System.Drawing.Point(22, 99);
            this.cbPSTW2_3.Name = "cbPSTW2_3";
            this.cbPSTW2_3.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW2_3.TabIndex = 72;
            this.cbPSTW2_3.Text = "-";
            this.cbPSTW2_3.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_2
            // 
            this.cbPSTW2_2.AutoSize = true;
            this.cbPSTW2_2.Location = new System.Drawing.Point(22, 80);
            this.cbPSTW2_2.Name = "cbPSTW2_2";
            this.cbPSTW2_2.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW2_2.TabIndex = 71;
            this.cbPSTW2_2.Text = "-";
            this.cbPSTW2_2.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_1
            // 
            this.cbPSTW2_1.AutoSize = true;
            this.cbPSTW2_1.Location = new System.Drawing.Point(22, 61);
            this.cbPSTW2_1.Name = "cbPSTW2_1";
            this.cbPSTW2_1.Size = new System.Drawing.Size(200, 21);
            this.cbPSTW2_1.TabIndex = 70;
            this.cbPSTW2_1.Text = "Homing to current position";
            this.cbPSTW2_1.UseVisualStyleBackColor = true;
            // 
            // cbPSTW2_0
            // 
            this.cbPSTW2_0.AutoSize = true;
            this.cbPSTW2_0.Location = new System.Drawing.Point(22, 42);
            this.cbPSTW2_0.Name = "cbPSTW2_0";
            this.cbPSTW2_0.Size = new System.Drawing.Size(35, 21);
            this.cbPSTW2_0.TabIndex = 69;
            this.cbPSTW2_0.Text = "-";
            this.cbPSTW2_0.UseVisualStyleBackColor = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(195, 8);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(52, 17);
            this.label25.TabIndex = 39;
            this.label25.Text = "Output";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbDebugPrev
            // 
            this.lbDebugPrev.AutoSize = true;
            this.lbDebugPrev.Location = new System.Drawing.Point(244, 21);
            this.lbDebugPrev.Name = "lbDebugPrev";
            this.lbDebugPrev.Size = new System.Drawing.Size(18, 17);
            this.lbDebugPrev.TabIndex = 37;
            this.lbDebugPrev.Text = "<<";
            this.lbDebugPrev.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbDebugPrev.Click += new System.EventHandler(this.LbDebugPrev_Click);
            // 
            // lbDebugNext
            // 
            this.lbDebugNext.AutoSize = true;
            this.lbDebugNext.Location = new System.Drawing.Point(268, 21);
            this.lbDebugNext.Name = "lbDebugNext";
            this.lbDebugNext.Size = new System.Drawing.Size(18, 17);
            this.lbDebugNext.TabIndex = 36;
            this.lbDebugNext.Text = ">>";
            this.lbDebugNext.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbDebugNext.Click += new System.EventHandler(this.LbDebugNext_Click);
            // 
            // gbDynamic
            // 
            this.gbDynamic.Controls.Add(this.txRecordSelection);
            this.gbDynamic.Controls.Add(this.label27);
            this.gbDynamic.Controls.Add(this.lbDynamicPrev);
            this.gbDynamic.Controls.Add(this.lbDynamicNext);
            this.gbDynamic.Controls.Add(this.label21);
            this.gbDynamic.Controls.Add(this.label20);
            this.gbDynamic.Controls.Add(this.label19);
            this.gbDynamic.Controls.Add(this.lbUnitVel);
            this.gbDynamic.Controls.Add(this.lbUnitPos);
            this.gbDynamic.Controls.Add(this.label16);
            this.gbDynamic.Controls.Add(this.txUnitVel);
            this.gbDynamic.Controls.Add(this.label15);
            this.gbDynamic.Controls.Add(this.txUnitPos);
            this.gbDynamic.Controls.Add(this.label14);
            this.gbDynamic.Controls.Add(this.label10);
            this.gbDynamic.Controls.Add(this.txTargetPosition);
            this.gbDynamic.Controls.Add(this.label13);
            this.gbDynamic.Controls.Add(this.txTargetVelocity);
            this.gbDynamic.Controls.Add(this.txOverride);
            this.gbDynamic.Controls.Add(this.label11);
            this.gbDynamic.Controls.Add(this.txDec);
            this.gbDynamic.Controls.Add(this.txAcc);
            this.gbDynamic.Controls.Add(this.label12);
            this.gbDynamic.Location = new System.Drawing.Point(491, 87);
            this.gbDynamic.Name = "gbDynamic";
            this.gbDynamic.Size = new System.Drawing.Size(304, 444);
            this.gbDynamic.TabIndex = 11;
            this.gbDynamic.TabStop = false;
            this.gbDynamic.Text = "Dynamic";
            // 
            // lbDynamicPrev
            // 
            this.lbDynamicPrev.AutoSize = true;
            this.lbDynamicPrev.Location = new System.Drawing.Point(244, 21);
            this.lbDynamicPrev.Name = "lbDynamicPrev";
            this.lbDynamicPrev.Size = new System.Drawing.Size(18, 17);
            this.lbDynamicPrev.TabIndex = 33;
            this.lbDynamicPrev.Text = "<<";
            this.lbDynamicPrev.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbDynamicPrev.Click += new System.EventHandler(this.LbDynamicPrev_Click);
            // 
            // lbDynamicNext
            // 
            this.lbDynamicNext.AutoSize = true;
            this.lbDynamicNext.Location = new System.Drawing.Point(268, 21);
            this.lbDynamicNext.Name = "lbDynamicNext";
            this.lbDynamicNext.Size = new System.Drawing.Size(18, 17);
            this.lbDynamicNext.TabIndex = 4;
            this.lbDynamicNext.Text = ">>";
            this.lbDynamicNext.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbDynamicNext.Click += new System.EventHandler(this.LbDynamicNext_Click);
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(227, 272);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 17);
            this.label21.TabIndex = 32;
            this.label21.Text = "%";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(227, 333);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(60, 17);
            this.label20.TabIndex = 31;
            this.label20.Text = "%";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(227, 303);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(60, 17);
            this.label19.TabIndex = 30;
            this.label19.Text = "%";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbUnitVel
            // 
            this.lbUnitVel.Location = new System.Drawing.Point(227, 93);
            this.lbUnitVel.Name = "lbUnitVel";
            this.lbUnitVel.Size = new System.Drawing.Size(60, 17);
            this.lbUnitVel.TabIndex = 29;
            this.lbUnitVel.Text = "unit";
            this.lbUnitVel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbUnitPos
            // 
            this.lbUnitPos.Location = new System.Drawing.Point(227, 63);
            this.lbUnitPos.Name = "lbUnitPos";
            this.lbUnitPos.Size = new System.Drawing.Size(60, 17);
            this.lbUnitPos.TabIndex = 28;
            this.lbUnitPos.Text = "unit";
            this.lbUnitPos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(42, 392);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(94, 17);
            this.label16.TabIndex = 27;
            this.label16.Text = "Velocity unit:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txUnitVel
            // 
            this.txUnitVel.Location = new System.Drawing.Point(142, 388);
            this.txUnitVel.Name = "txUnitVel";
            this.txUnitVel.Size = new System.Drawing.Size(79, 24);
            this.txUnitVel.TabIndex = 26;
            this.txUnitVel.Text = "mm/s";
            this.txUnitVel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txUnitVel.TextChanged += new System.EventHandler(this.TxUnitVel_TextChanged);
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(43, 362);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(93, 17);
            this.label15.TabIndex = 25;
            this.label15.Text = "Position unit:";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txUnitPos
            // 
            this.txUnitPos.Location = new System.Drawing.Point(142, 358);
            this.txUnitPos.Name = "txUnitPos";
            this.txUnitPos.Size = new System.Drawing.Size(79, 24);
            this.txUnitPos.TabIndex = 24;
            this.txUnitPos.Text = "mm";
            this.txUnitPos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txUnitPos.TextChanged += new System.EventHandler(this.TxUnitPos_TextChanged);
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(27, 63);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(109, 17);
            this.label14.TabIndex = 23;
            this.label14.Text = "Target position:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(27, 93);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(109, 17);
            this.label10.TabIndex = 21;
            this.label10.Text = "Target velocity:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txTargetPosition
            // 
            this.txTargetPosition.Location = new System.Drawing.Point(142, 59);
            this.txTargetPosition.Name = "txTargetPosition";
            this.txTargetPosition.Size = new System.Drawing.Size(79, 24);
            this.txTargetPosition.TabIndex = 22;
            this.txTargetPosition.Text = "0";
            this.txTargetPosition.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(68, 272);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 17);
            this.label13.TabIndex = 15;
            this.label13.Text = "Override:";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txTargetVelocity
            // 
            this.txTargetVelocity.Location = new System.Drawing.Point(142, 89);
            this.txTargetVelocity.Name = "txTargetVelocity";
            this.txTargetVelocity.Size = new System.Drawing.Size(79, 24);
            this.txTargetVelocity.TabIndex = 20;
            this.txTargetVelocity.Text = "0";
            this.txTargetVelocity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txOverride
            // 
            this.txOverride.Location = new System.Drawing.Point(142, 269);
            this.txOverride.Name = "txOverride";
            this.txOverride.Size = new System.Drawing.Size(79, 24);
            this.txOverride.TabIndex = 14;
            this.txOverride.Text = "100";
            this.txOverride.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(42, 303);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 17);
            this.label11.TabIndex = 19;
            this.label11.Text = "Acceleration:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txDec
            // 
            this.txDec.Location = new System.Drawing.Point(142, 329);
            this.txDec.Name = "txDec";
            this.txDec.Size = new System.Drawing.Size(79, 24);
            this.txDec.TabIndex = 16;
            this.txDec.Text = "100";
            this.txDec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txAcc
            // 
            this.txAcc.Location = new System.Drawing.Point(142, 299);
            this.txAcc.Name = "txAcc";
            this.txAcc.Size = new System.Drawing.Size(79, 24);
            this.txAcc.TabIndex = 18;
            this.txAcc.Text = "100";
            this.txAcc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(41, 333);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(95, 17);
            this.label12.TabIndex = 17;
            this.label12.Text = "Deceleration:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbTakeControl
            // 
            this.cbTakeControl.AutoSize = true;
            this.cbTakeControl.Location = new System.Drawing.Point(30, 41);
            this.cbTakeControl.Name = "cbTakeControl";
            this.cbTakeControl.Size = new System.Drawing.Size(184, 21);
            this.cbTakeControl.TabIndex = 2;
            this.cbTakeControl.Text = "Take control via modbus";
            this.cbTakeControl.UseVisualStyleBackColor = true;
            this.cbTakeControl.CheckedChanged += new System.EventHandler(this.CbTakeControl_CheckedChanged);
            // 
            // gbConnect
            // 
            this.gbConnect.Controls.Add(this.btConnect);
            this.gbConnect.Location = new System.Drawing.Point(20, 87);
            this.gbConnect.Name = "gbConnect";
            this.gbConnect.Size = new System.Drawing.Size(224, 92);
            this.gbConnect.TabIndex = 12;
            this.gbConnect.TabStop = false;
            this.gbConnect.Text = "Connect";
            // 
            // gbTakeControl
            // 
            this.gbTakeControl.Controls.Add(this.cbTakeControl);
            this.gbTakeControl.Enabled = false;
            this.gbTakeControl.Location = new System.Drawing.Point(250, 87);
            this.gbTakeControl.Name = "gbTakeControl";
            this.gbTakeControl.Size = new System.Drawing.Size(235, 92);
            this.gbTakeControl.TabIndex = 13;
            this.gbTakeControl.TabStop = false;
            this.gbTakeControl.Text = "Take Control";
            // 
            // btGo
            // 
            this.btGo.Location = new System.Drawing.Point(14, 236);
            this.btGo.Name = "btGo";
            this.btGo.Size = new System.Drawing.Size(105, 98);
            this.btGo.TabIndex = 7;
            this.btGo.Text = "Go";
            this.btGo.UseVisualStyleBackColor = true;
            // 
            // tsCmmtStatus
            // 
            this.tsCmmtStatus.AutoSize = false;
            this.tsCmmtStatus.Name = "tsCmmtStatus";
            this.tsCmmtStatus.Size = new System.Drawing.Size(600, 20);
            this.tsCmmtStatus.Text = "CMMT status";
            this.tsCmmtStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.Location = new System.Drawing.Point(15, 122);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(121, 18);
            this.label27.TabIndex = 35;
            this.label27.Text = "Record selection:";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // rbMoveAbsolute
            // 
            this.rbMoveAbsolute.AutoSize = true;
            this.rbMoveAbsolute.Location = new System.Drawing.Point(27, 62);
            this.rbMoveAbsolute.Name = "rbMoveAbsolute";
            this.rbMoveAbsolute.Size = new System.Drawing.Size(123, 21);
            this.rbMoveAbsolute.TabIndex = 8;
            this.rbMoveAbsolute.TabStop = true;
            this.rbMoveAbsolute.Text = "Move absolute";
            this.rbMoveAbsolute.UseVisualStyleBackColor = true;
            // 
            // rbMoveRelative
            // 
            this.rbMoveRelative.AutoSize = true;
            this.rbMoveRelative.Location = new System.Drawing.Point(27, 89);
            this.rbMoveRelative.Name = "rbMoveRelative";
            this.rbMoveRelative.Size = new System.Drawing.Size(116, 21);
            this.rbMoveRelative.TabIndex = 9;
            this.rbMoveRelative.TabStop = true;
            this.rbMoveRelative.Text = "Move relative";
            this.rbMoveRelative.UseVisualStyleBackColor = true;
            // 
            // rbRecordSelection
            // 
            this.rbRecordSelection.AutoSize = true;
            this.rbRecordSelection.Location = new System.Drawing.Point(27, 116);
            this.rbRecordSelection.Name = "rbRecordSelection";
            this.rbRecordSelection.Size = new System.Drawing.Size(136, 21);
            this.rbRecordSelection.TabIndex = 10;
            this.rbRecordSelection.TabStop = true;
            this.rbRecordSelection.Text = "Record selection";
            this.rbRecordSelection.UseVisualStyleBackColor = true;
            // 
            // rbHoming
            // 
            this.rbHoming.AutoSize = true;
            this.rbHoming.Location = new System.Drawing.Point(27, 35);
            this.rbHoming.Name = "rbHoming";
            this.rbHoming.Size = new System.Drawing.Size(79, 21);
            this.rbHoming.TabIndex = 11;
            this.rbHoming.TabStop = true;
            this.rbHoming.Text = "Homing";
            this.rbHoming.UseVisualStyleBackColor = true;
            // 
            // btStop
            // 
            this.btStop.Location = new System.Drawing.Point(125, 236);
            this.btStop.Name = "btStop";
            this.btStop.Size = new System.Drawing.Size(105, 98);
            this.btStop.TabIndex = 12;
            this.btStop.Text = "Stop";
            this.btStop.UseVisualStyleBackColor = true;
            // 
            // btClear
            // 
            this.btClear.Location = new System.Drawing.Point(236, 236);
            this.btClear.Name = "btClear";
            this.btClear.Size = new System.Drawing.Size(105, 98);
            this.btClear.TabIndex = 13;
            this.btClear.Text = "Clear";
            this.btClear.UseVisualStyleBackColor = true;
            // 
            // btAck
            // 
            this.btAck.Location = new System.Drawing.Point(347, 236);
            this.btAck.Name = "btAck";
            this.btAck.Size = new System.Drawing.Size(105, 98);
            this.btAck.TabIndex = 14;
            this.btAck.Text = "Ack";
            this.btAck.UseVisualStyleBackColor = true;
            // 
            // gbMode
            // 
            this.gbMode.Controls.Add(this.rbRecordSelection);
            this.gbMode.Controls.Add(this.rbMoveAbsolute);
            this.gbMode.Controls.Add(this.rbMoveRelative);
            this.gbMode.Controls.Add(this.rbHoming);
            this.gbMode.Location = new System.Drawing.Point(14, 75);
            this.gbMode.Name = "gbMode";
            this.gbMode.Size = new System.Drawing.Size(181, 155);
            this.gbMode.TabIndex = 15;
            this.gbMode.TabStop = false;
            this.gbMode.Text = "Mode";
            // 
            // txRecordSelection
            // 
            this.txRecordSelection.Location = new System.Drawing.Point(142, 119);
            this.txRecordSelection.Name = "txRecordSelection";
            this.txRecordSelection.Size = new System.Drawing.Size(79, 24);
            this.txRecordSelection.TabIndex = 36;
            this.txRecordSelection.Text = "100";
            this.txRecordSelection.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gbStatus
            // 
            this.gbStatus.Controls.Add(this.lbRecordSelectionStatus);
            this.gbStatus.Controls.Add(this.lbMoveStatus);
            this.gbStatus.Controls.Add(this.lbHomingStatus);
            this.gbStatus.Location = new System.Drawing.Point(201, 75);
            this.gbStatus.Name = "gbStatus";
            this.gbStatus.Size = new System.Drawing.Size(251, 155);
            this.gbStatus.TabIndex = 16;
            this.gbStatus.TabStop = false;
            this.gbStatus.Text = "Status";
            // 
            // lbHomingStatus
            // 
            this.lbHomingStatus.AutoSize = true;
            this.lbHomingStatus.Location = new System.Drawing.Point(26, 37);
            this.lbHomingStatus.Name = "lbHomingStatus";
            this.lbHomingStatus.Size = new System.Drawing.Size(99, 17);
            this.lbHomingStatus.TabIndex = 0;
            this.lbHomingStatus.Text = "homing status";
            // 
            // btJog2
            // 
            this.btJog2.Location = new System.Drawing.Point(312, 21);
            this.btJog2.Name = "btJog2";
            this.btJog2.Size = new System.Drawing.Size(67, 54);
            this.btJog2.TabIndex = 17;
            this.btJog2.Text = "Jog -";
            this.btJog2.UseVisualStyleBackColor = true;
            // 
            // btJog1
            // 
            this.btJog1.Location = new System.Drawing.Point(385, 21);
            this.btJog1.Name = "btJog1";
            this.btJog1.Size = new System.Drawing.Size(67, 54);
            this.btJog1.TabIndex = 18;
            this.btJog1.Text = "Jog +";
            this.btJog1.UseVisualStyleBackColor = true;
            // 
            // lbMoveStatus
            // 
            this.lbMoveStatus.AutoSize = true;
            this.lbMoveStatus.Location = new System.Drawing.Point(26, 64);
            this.lbMoveStatus.Name = "lbMoveStatus";
            this.lbMoveStatus.Size = new System.Drawing.Size(86, 17);
            this.lbMoveStatus.TabIndex = 1;
            this.lbMoveStatus.Text = "move status";
            // 
            // lbRecordSelectionStatus
            // 
            this.lbRecordSelectionStatus.AutoSize = true;
            this.lbRecordSelectionStatus.Location = new System.Drawing.Point(26, 118);
            this.lbRecordSelectionStatus.Name = "lbRecordSelectionStatus";
            this.lbRecordSelectionStatus.Size = new System.Drawing.Size(146, 17);
            this.lbRecordSelectionStatus.TabIndex = 2;
            this.lbRecordSelectionStatus.Text = "record selction status";
            // 
            // frCMMTModbus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(822, 565);
            this.Controls.Add(this.gbTakeControl);
            this.Controls.Add(this.gbConnect);
            this.Controls.Add(this.gbSetting);
            this.Controls.Add(this.gbDynamic);
            this.Controls.Add(this.gbControl);
            this.Controls.Add(this.gbDebug);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ssStatus);
            this.Font = new System.Drawing.Font("MetaPlusLF", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frCMMTModbus";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CMMT Modbus";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrCMMTModbus_FormClosing);
            this.Load += new System.EventHandler(this.FrCMMTModbus_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ssStatus.ResumeLayout(false);
            this.ssStatus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.gbSetting.ResumeLayout(false);
            this.gbSetting.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.gbControl.ResumeLayout(false);
            this.gbControl.PerformLayout();
            this.gbDebug.ResumeLayout(false);
            this.gbDebug.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tpRaw.ResumeLayout(false);
            this.tpRaw.PerformLayout();
            this.tpSTW1.ResumeLayout(false);
            this.tpSTW1.PerformLayout();
            this.tpZSW1.ResumeLayout(false);
            this.tpZSW1.PerformLayout();
            this.tpPSTW1.ResumeLayout(false);
            this.tpPSTW1.PerformLayout();
            this.tpPZSW1.ResumeLayout(false);
            this.tpPZSW1.PerformLayout();
            this.tpPSTW2.ResumeLayout(false);
            this.tpPSTW2.PerformLayout();
            this.gbDynamic.ResumeLayout(false);
            this.gbDynamic.PerformLayout();
            this.gbConnect.ResumeLayout(false);
            this.gbTakeControl.ResumeLayout(false);
            this.gbTakeControl.PerformLayout();
            this.gbMode.ResumeLayout(false);
            this.gbMode.PerformLayout();
            this.gbStatus.ResumeLayout(false);
            this.gbStatus.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btConnect;
        private System.Windows.Forms.TextBox txIPAddress;
        private System.Windows.Forms.Timer tCycle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txExtendedOW;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txExtendedIW;
        private System.Windows.Forms.StatusStrip ssStatus;
        private System.Windows.Forms.ToolStripStatusLabel lbStatus;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txRawIn;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txVelocityOutputFG;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txVelocityInputFG;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txPositionOutputFG;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txPositionInputFG;
        private System.Windows.Forms.GroupBox gbSetting;
        private System.Windows.Forms.GroupBox gbControl;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txPort;
        private System.Windows.Forms.GroupBox gbDebug;
        private System.Windows.Forms.GroupBox gbDynamic;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lbUnitVel;
        private System.Windows.Forms.Label lbUnitPos;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txUnitVel;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txUnitPos;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txTargetPosition;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txTargetVelocity;
        private System.Windows.Forms.TextBox txOverride;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txDec;
        private System.Windows.Forms.TextBox txAcc;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbSettingPrev;
        private System.Windows.Forms.Label lbSettingNext;
        private System.Windows.Forms.Label lbDebugPrev;
        private System.Windows.Forms.Label lbDebugNext;
        private System.Windows.Forms.Label lbDynamicPrev;
        private System.Windows.Forms.Label lbDynamicNext;
        private System.Windows.Forms.CheckBox cbTakeControl;
        private System.Windows.Forms.GroupBox gbConnect;
        private System.Windows.Forms.GroupBox gbTakeControl;
        private System.Windows.Forms.CheckBox cbEnableDrive;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpRaw;
        private System.Windows.Forms.TextBox txRawOut;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TabPage tpSTW1;
        private System.Windows.Forms.CheckBox cbSTW1_7;
        private System.Windows.Forms.CheckBox cbSTW1_6;
        private System.Windows.Forms.CheckBox cbSTW1_5;
        private System.Windows.Forms.CheckBox cbSTW1_4;
        private System.Windows.Forms.CheckBox cbSTW1_3;
        private System.Windows.Forms.CheckBox cbSTW1_2;
        private System.Windows.Forms.CheckBox cbSTW1_1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.CheckBox cbSTW1_0;
        private System.Windows.Forms.TabPage tpZSW1;
        private System.Windows.Forms.TabPage tpPSTW1;
        private System.Windows.Forms.TabPage tpPZSW1;
        private System.Windows.Forms.TabPage tpPSTW2;
        private System.Windows.Forms.CheckBox cbSTW1_14;
        private System.Windows.Forms.CheckBox cbSTW1_13;
        private System.Windows.Forms.CheckBox cbSTW1_12;
        private System.Windows.Forms.CheckBox cbSTW1_11;
        private System.Windows.Forms.CheckBox cbSTW1_10;
        private System.Windows.Forms.CheckBox cbSTW1_9;
        private System.Windows.Forms.CheckBox cbSTW1_8;
        private System.Windows.Forms.CheckBox cbZSW1_15;
        private System.Windows.Forms.CheckBox cbZSW1_14;
        private System.Windows.Forms.CheckBox cbZSW1_13;
        private System.Windows.Forms.CheckBox cbZSW1_12;
        private System.Windows.Forms.CheckBox cbZSW1_10;
        private System.Windows.Forms.CheckBox cbZSW1_11;
        private System.Windows.Forms.CheckBox cbZSW1_8;
        private System.Windows.Forms.CheckBox cbZSW1_7;
        private System.Windows.Forms.CheckBox cbZSW1_6;
        private System.Windows.Forms.CheckBox cbZSW1_5;
        private System.Windows.Forms.CheckBox cbZSW1_4;
        private System.Windows.Forms.CheckBox cbZSW1_3;
        private System.Windows.Forms.CheckBox cbZSW1_2;
        private System.Windows.Forms.CheckBox cbZSW1_1;
        private System.Windows.Forms.CheckBox cbZSW1_0;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.CheckBox cbPSTW1_14;
        private System.Windows.Forms.CheckBox cbPSTW1_13;
        private System.Windows.Forms.CheckBox cbPSTW1_12;
        private System.Windows.Forms.CheckBox cbPSTW1_11;
        private System.Windows.Forms.CheckBox cbPSTW1_10;
        private System.Windows.Forms.CheckBox cbPSTW1_9;
        private System.Windows.Forms.CheckBox cbPSTW1_8;
        private System.Windows.Forms.CheckBox cbPSTW1_7;
        private System.Windows.Forms.CheckBox cbPSTW1_6;
        private System.Windows.Forms.CheckBox cbPSTW1_5;
        private System.Windows.Forms.CheckBox cbPSTW1_4;
        private System.Windows.Forms.CheckBox cbPSTW1_3;
        private System.Windows.Forms.CheckBox cbPSTW1_2;
        private System.Windows.Forms.CheckBox cbPSTW1_1;
        private System.Windows.Forms.CheckBox cbPSTW1_0;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.CheckBox cbPZSW1_14;
        private System.Windows.Forms.CheckBox cbPZSW1_13;
        private System.Windows.Forms.CheckBox cbPZSW1_12;
        private System.Windows.Forms.CheckBox cbPZSW1_11;
        private System.Windows.Forms.CheckBox cbPZSW1_10;
        private System.Windows.Forms.CheckBox cbPZSW1_9;
        private System.Windows.Forms.CheckBox cbPZSW1_8;
        private System.Windows.Forms.CheckBox cbPZSW1_7;
        private System.Windows.Forms.CheckBox cbPZSW1_6;
        private System.Windows.Forms.CheckBox cbPZSW1_5;
        private System.Windows.Forms.CheckBox cbPZSW1_4;
        private System.Windows.Forms.CheckBox cbPZSW1_3;
        private System.Windows.Forms.CheckBox cbPZSW1_2;
        private System.Windows.Forms.CheckBox cbPZSW1_1;
        private System.Windows.Forms.CheckBox cbPZSW1_0;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.CheckBox cbPSTW2_14;
        private System.Windows.Forms.CheckBox cbPSTW2_13;
        private System.Windows.Forms.CheckBox cbPSTW2_12;
        private System.Windows.Forms.CheckBox cbPSTW2_11;
        private System.Windows.Forms.CheckBox cbPSTW2_10;
        private System.Windows.Forms.CheckBox cbPSTW2_9;
        private System.Windows.Forms.CheckBox cbPSTW2_8;
        private System.Windows.Forms.CheckBox cbPSTW2_7;
        private System.Windows.Forms.CheckBox cbPSTW2_6;
        private System.Windows.Forms.CheckBox cbPSTW2_5;
        private System.Windows.Forms.CheckBox cbPSTW2_4;
        private System.Windows.Forms.CheckBox cbPSTW2_3;
        private System.Windows.Forms.CheckBox cbPSTW2_2;
        private System.Windows.Forms.CheckBox cbPSTW2_1;
        private System.Windows.Forms.CheckBox cbPSTW2_0;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.CheckBox cbSTW1_15;
        private System.Windows.Forms.CheckBox cbZSW1_9;
        private System.Windows.Forms.CheckBox cbPSTW1_15;
        private System.Windows.Forms.CheckBox cbPZSW1_15;
        private System.Windows.Forms.CheckBox cbPSTW2_15;
        private System.Windows.Forms.CheckBox cbSTW1Write;
        private System.Windows.Forms.CheckBox cbPSTW1Write;
        private System.Windows.Forms.CheckBox cbPSTW2Write;
        private System.Windows.Forms.ToolStripStatusLabel tsCmmtStatus;
        private System.Windows.Forms.Button btGo;
        private System.Windows.Forms.RadioButton rbHoming;
        private System.Windows.Forms.RadioButton rbRecordSelection;
        private System.Windows.Forms.RadioButton rbMoveRelative;
        private System.Windows.Forms.RadioButton rbMoveAbsolute;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.GroupBox gbMode;
        private System.Windows.Forms.Button btAck;
        private System.Windows.Forms.Button btClear;
        private System.Windows.Forms.Button btStop;
        private System.Windows.Forms.TextBox txRecordSelection;
        private System.Windows.Forms.Button btJog1;
        private System.Windows.Forms.Button btJog2;
        private System.Windows.Forms.GroupBox gbStatus;
        private System.Windows.Forms.Label lbRecordSelectionStatus;
        private System.Windows.Forms.Label lbMoveStatus;
        private System.Windows.Forms.Label lbHomingStatus;
    }
}