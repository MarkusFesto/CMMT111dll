﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using CMMTt111;

namespace CMMT_EP_ModbusTCP
{
    public partial class frCMMTModbus : Form
    {
        #region general global variable
        bool debugActive = false;
        #endregion

        #region global variable for CMMT
        festoCMMT festoCMMT = new festoCMMT();
        byte ExtendedIW;
        byte ExtendedOW;
        #endregion 

        #region global variable for save data
        private string[] savsplit;
        #endregion

        private void FrCMMTModbus_Load(object sender, EventArgs e)
        {
            this.Width = 834;
            this.Height = 612;

            ReadSavedParameter();
            StoreSavedParameter();
        }

        private void FrCMMTModbus_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Things while closing
            WriteSavedParameter();
        }

        public frCMMTModbus()
        {
            InitializeComponent();
        }
           
        private void BtConnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (btConnect.Text == "Connect")
                {
                    lbStatus.Text = "Connecting..";
                    ExtendedIW = byte.Parse(txExtendedIW.Text);
                    ExtendedOW = byte.Parse(txExtendedOW.Text);
                    int myPort = Int32.Parse(txPort.Text);

                    festoCMMT.connectModbustcp(txIPAddress.Text, myPort, ExtendedIW, ExtendedOW);
                    tCycle.Enabled = true; 
                }
                else
                {
                    festoCMMT.disconnectModbustcp();
                }
            }
            catch
            {
                tCycle.Enabled = false;
                lbStatus.Text = "Can't connect";
            }
        }

        private void TCycle_Tick(object sender, EventArgs e)
        {
            bool Connected = false;

            #region Check Connection
            try
            {
                Connected = festoCMMT.connectedModbustcp();
                if (Connected)
                {
                    lbStatus.Text = "Connected";
                    btConnect.Text = "Disconnect";
                    gbTakeControl.Enabled = true;
                }
                else
                {
                    lbStatus.Text = "Not Connected";
                    btConnect.Text = "Connect";
                    gbTakeControl.Enabled = false;
                    cbTakeControl.Checked = false;
                }
            }
            catch { }
            #endregion

            if (Connected)
            {
                festoCMMT.ConvertPositionInput = float.Parse(txPositionInputFG.Text);
                festoCMMT.ConvertVelocityInput = float.Parse(txVelocityInputFG.Text);
                festoCMMT.ConvertPositionOutput = float.Parse(txPositionOutputFG.Text);
                festoCMMT.ConvertVelocityOutput = float.Parse(txVelocityOutputFG.Text);

                festoCMMT.readInW();  // read using cmmtt111 internal modbus tcp
                festoCMMT.processStandardInput(); // Process 12 IW, structured to input variable
                
               




                festoCMMT.processStandardOutput(); // Process 12 OW, structured from output variable
                festoCMMT.writeOutW();  // write using cmmtt111 internal modbus tcp

                if (debugActive) { MonitorIO() };
            }
        }

        private void MonitorIO()
        {
            #region Monitor I/O 
            
            #region debug Raw I/O
            string sDebug = "";
            for (int i = 0; i < 12 + ExtendedIW; i++)
            {
                sDebug = sDebug + "[" + i.ToString("00") + "] " + festoCMMT.InW[i].ToString() + Environment.NewLine;
            }
            txRawIn.Text = sDebug;

            sDebug = "";
            for (int i = 0; i < 12 + ExtendedOW; i++)
            {
                sDebug = sDebug + "[" + i.ToString("00") + "] " + festoCMMT.OutW[i].ToString() + Environment.NewLine;
            }
            txRawOut.Text = sDebug;
            #endregion

            #region debug STW1;
            if (!cbSTW1Write.Checked)
            {
                festoCMMT.accessOutputWord_STW1 = false;
                cbSTW1_0.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 0);
                cbSTW1_1.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 1);
                cbSTW1_2.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 2);
                cbSTW1_3.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 3);
                cbSTW1_4.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 4);
                cbSTW1_5.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 5);
                cbSTW1_6.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 6);
                cbSTW1_7.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 7);
                cbSTW1_8.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 8);
                cbSTW1_9.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 9);
                cbSTW1_10.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 10);
                cbSTW1_11.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 11);
                cbSTW1_12.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 12);
                cbSTW1_13.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 13);
                cbSTW1_14.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 14);
                cbSTW1_15.Checked = festoCMMT.GetBitfromInt(festoCMMT.STW1, 15);
            }
            else
            {
                festoCMMT.accessOutputWord_STW1 = true;
                festoCMMT.STW1 = 1 * Convert.ToInt32(cbSTW1_0.Checked) +
                                 2 * Convert.ToInt32(cbSTW1_1.Checked) +
                                 4 * Convert.ToInt32(cbSTW1_2.Checked) +
                                 8 * Convert.ToInt32(cbSTW1_3.Checked) +
                                 16 * Convert.ToInt32(cbSTW1_4.Checked) +
                                 32 * Convert.ToInt32(cbSTW1_5.Checked) +
                                 64 * Convert.ToInt32(cbSTW1_6.Checked) +
                                 128 * Convert.ToInt32(cbSTW1_7.Checked) +
                                 256 * Convert.ToInt32(cbSTW1_8.Checked) +
                                 512 * Convert.ToInt32(cbSTW1_9.Checked) +
                                 1024 * Convert.ToInt32(cbSTW1_10.Checked) +
                                 2048 * Convert.ToInt32(cbSTW1_11.Checked) +
                                 4096 * Convert.ToInt32(cbSTW1_12.Checked) +
                                 8192 * Convert.ToInt32(cbSTW1_13.Checked) +
                                 16384 * Convert.ToInt32(cbSTW1_14.Checked) +
                                 32768 * Convert.ToInt32(cbSTW1_15.Checked);
            }
            #endregion

            #region debug ZSW1;
            cbZSW1_0.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 0);
            cbZSW1_1.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 1);
            cbZSW1_2.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 2);
            cbZSW1_3.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 3);
            cbZSW1_4.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 4);
            cbZSW1_5.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 5);
            cbZSW1_6.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 6);
            cbZSW1_7.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 7);
            cbZSW1_8.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 8);
            cbZSW1_9.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 9);
            cbZSW1_10.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 10);
            cbZSW1_11.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 11);
            cbZSW1_12.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 12);
            cbZSW1_13.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 13);
            cbZSW1_14.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 14);
            cbZSW1_15.Checked = festoCMMT.GetBitfromInt(festoCMMT.ZSW1, 15);
            #endregion

            #region debug POS_STW1;
            if (!cbPSTW1Write.Checked)
            {
                festoCMMT.accessOutputWord_POS_STW1 = false;
                cbPSTW1_0.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 0);
                cbPSTW1_1.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 1);
                cbPSTW1_2.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 2);
                cbPSTW1_3.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 3);
                cbPSTW1_4.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 4);
                cbPSTW1_5.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 5);
                cbPSTW1_6.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 6);
                cbPSTW1_7.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 7);
                cbPSTW1_8.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 8);
                cbPSTW1_9.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 9);
                cbPSTW1_10.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 10);
                cbPSTW1_11.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 11);
                cbPSTW1_12.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 12);
                cbPSTW1_13.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 13);
                cbPSTW1_14.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 14);
                cbPSTW1_15.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW1, 15);
            }
            else
            {
                festoCMMT.accessOutputWord_POS_STW1 = true;
                festoCMMT.POS_STW1 = 1 * Convert.ToInt32(cbPSTW1_0.Checked) +
                                     2 * Convert.ToInt32(cbPSTW1_1.Checked) +
                                     4 * Convert.ToInt32(cbPSTW1_2.Checked) +
                                     8 * Convert.ToInt32(cbPSTW1_3.Checked) +
                                     16 * Convert.ToInt32(cbPSTW1_4.Checked) +
                                     32 * Convert.ToInt32(cbPSTW1_5.Checked) +
                                     64 * Convert.ToInt32(cbPSTW1_6.Checked) +
                                     128 * Convert.ToInt32(cbPSTW1_7.Checked) +
                                     256 * Convert.ToInt32(cbPSTW1_8.Checked) +
                                     512 * Convert.ToInt32(cbPSTW1_9.Checked) +
                                     1024 * Convert.ToInt32(cbPSTW1_10.Checked) +
                                     2048 * Convert.ToInt32(cbPSTW1_11.Checked) +
                                     4096 * Convert.ToInt32(cbPSTW1_12.Checked) +
                                     8192 * Convert.ToInt32(cbPSTW1_13.Checked) +
                                     16384 * Convert.ToInt32(cbPSTW1_14.Checked) +
                                     32768 * Convert.ToInt32(cbPSTW1_15.Checked);
            }
            #endregion

            #region debug POS_ZSW1;
            cbPZSW1_0.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 0);
            cbPZSW1_1.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 1);
            cbPZSW1_2.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 2);
            cbPZSW1_3.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 3);
            cbPZSW1_4.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 4);
            cbPZSW1_5.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 5);
            cbPZSW1_6.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 6);
            cbPZSW1_7.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 7);
            cbPZSW1_8.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 8);
            cbPZSW1_9.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 9);
            cbPZSW1_10.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 10);
            cbPZSW1_11.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 11);
            cbPZSW1_12.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 12);
            cbPZSW1_13.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 13);
            cbPZSW1_14.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 14);
            cbPZSW1_15.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_ZSW1, 15);
            #endregion

            #region debug POS_STW2;
            if (!cbPSTW2Write.Checked)
            {
                festoCMMT.accessOutputWord_POS_STW2 = false;
                cbPSTW2_0.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 0);
                cbPSTW2_1.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 1);
                cbPSTW2_2.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 2);
                cbPSTW2_3.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 3);
                cbPSTW2_4.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 4);
                cbPSTW2_5.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 5);
                cbPSTW2_6.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 6);
                cbPSTW2_7.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 7);
                cbPSTW2_8.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 8);
                cbPSTW2_9.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 9);
                cbPSTW2_10.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 10);
                cbPSTW2_11.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 11);
                cbPSTW2_12.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 12);
                cbPSTW2_13.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 13);
                cbPSTW2_14.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 14);
                cbPSTW2_15.Checked = festoCMMT.GetBitfromInt(festoCMMT.POS_STW2, 15);
            }
            else
            {
                festoCMMT.accessOutputWord_POS_STW2 = true;
                festoCMMT.POS_STW2 = 1 * Convert.ToInt32(cbPSTW2_0.Checked) +
                                     2 * Convert.ToInt32(cbPSTW2_1.Checked) +
                                     4 * Convert.ToInt32(cbPSTW2_2.Checked) +
                                     8 * Convert.ToInt32(cbPSTW2_3.Checked) +
                                     16 * Convert.ToInt32(cbPSTW2_4.Checked) +
                                     32 * Convert.ToInt32(cbPSTW2_5.Checked) +
                                     64 * Convert.ToInt32(cbPSTW2_6.Checked) +
                                     128 * Convert.ToInt32(cbPSTW2_7.Checked) +
                                     256 * Convert.ToInt32(cbPSTW2_8.Checked) +
                                     512 * Convert.ToInt32(cbPSTW2_9.Checked) +
                                     1024 * Convert.ToInt32(cbPSTW2_10.Checked) +
                                     2048 * Convert.ToInt32(cbPSTW2_11.Checked) +
                                     4096 * Convert.ToInt32(cbPSTW2_12.Checked) +
                                     8192 * Convert.ToInt32(cbPSTW2_13.Checked) +
                                     16384 * Convert.ToInt32(cbPSTW2_14.Checked) +
                                     32768 * Convert.ToInt32(cbPSTW2_15.Checked);
            }
            #endregion

            #endregion
        }

        #region savesettingdata
        private void ReadSavedParameter()
        {
            try
            {
                using (StreamReader readtext = new StreamReader("savcmmt.mrh"))
                {
                    string sav = readtext.ReadToEnd();
                    savsplit = sav.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                }
            }
            catch { }
        }
        private void StoreSavedParameter()
        {
            try
            {
                txIPAddress.Text = savsplit[0];
                txPort.Text = savsplit[1];
                txExtendedIW.Text = savsplit[2];
                txExtendedOW.Text = savsplit[3];
                txPositionInputFG.Text = savsplit[4];
                txVelocityInputFG.Text = savsplit[5];
                txPositionOutputFG.Text = savsplit[6];
                txVelocityOutputFG.Text = savsplit[7];
                txOverride.Text = savsplit[8];
                txAcc.Text = savsplit[9];
                txDec.Text = savsplit[10];
                txUnitPos.Text = savsplit[11];
                lbUnitPos.Text = txUnitPos.Text;
                txUnitVel.Text = savsplit[12];
                lbUnitVel.Text = txUnitVel.Text;
                //txIPAddress.Text = savsplit[13];
                //txIPAddress.Text = savsplit[14];
                //txIPAddress.Text = savsplit[15];
                //cbUploadPath.Checked = bool.Parse(savsplit[16]);
                //cbPath.SelectedIndex = int.Parse(savsplit[17]);

            }
            catch { }
        }
        private void WriteSavedParameter()
        {
            try
            {
                savsplit[0] = txIPAddress.Text;
                savsplit[1] = txPort.Text;
                savsplit[2] = txExtendedIW.Text;
                savsplit[3] = txExtendedOW.Text;
                savsplit[4] = txPositionInputFG.Text;
                savsplit[5] = txVelocityInputFG.Text;
                savsplit[6] = txPositionOutputFG.Text;
                savsplit[7] = txVelocityOutputFG.Text;
                savsplit[8] = txOverride.Text;
                savsplit[9] = txAcc.Text;
                savsplit[10] = txDec.Text;
                savsplit[11] = txUnitPos.Text;
                savsplit[12] = txUnitVel.Text;
                savsplit[13] = "13";
                savsplit[14] = "14";
                savsplit[15] = "15";
                //savsplit[16] = cbCheckLimit.Checked.ToString();
                //savsplit[17] = cbPath.SelectedIndex.ToString();
            }
            catch { }

            string sav = string.Join("\r\n", savsplit);
            using (StreamWriter writer = new StreamWriter("savcmmt.mrh"))
            {
                writer.WriteLine(sav);
            }
        }
        #endregion

        #region choose display
        private void LbDynamicPrev_Click(object sender, EventArgs e)
        {
            gbDynamic.Visible = false;
            gbSetting.Visible = false;
            gbDebug.Visible = true;
            debugActive = true;
            gbDebug.Left = 491;
        }
        private void LbDynamicNext_Click(object sender, EventArgs e)
        {
            gbDynamic.Visible = false;
            gbSetting.Visible = true;
            gbDebug.Visible = false;
            debugActive = false;
            gbSetting.Left = 491;
        }

        private void LbSettingPrev_Click(object sender, EventArgs e)
        {
            gbDynamic.Visible = true;
            gbSetting.Visible = false;
            gbDebug.Visible = false;
            debugActive = false;
            gbDynamic.Left = 491;
        }

        private void LbSettingNext_Click(object sender, EventArgs e)
        {
            gbDynamic.Visible = false;
            gbSetting.Visible = false;
            gbDebug.Visible = true;
            debugActive = true;
            gbDebug.Left = 491;
        }

        private void LbDebugPrev_Click(object sender, EventArgs e)
        {
            gbDynamic.Visible = false;
            gbSetting.Visible = true;
            gbDebug.Visible = false;
            debugActive = false;
            gbSetting.Left = 491;
        }

        private void LbDebugNext_Click(object sender, EventArgs e)
        {
            gbDynamic.Visible = true;
            gbSetting.Visible = false;
            gbDebug.Visible = false;
            debugActive = false;
            gbDynamic.Left = 491;
        }
        #endregion

        #region unitchange
        private void TxUnitPos_TextChanged(object sender, EventArgs e)
        {
            lbUnitPos.Text = txUnitPos.Text;
        }

        private void TxUnitVel_TextChanged(object sender, EventArgs e)
        {
            lbUnitVel.Text = txUnitVel.Text;
        }


        #endregion

        #region CMMT Control
        private void CbTakeControl_CheckedChanged(object sender, EventArgs e)
        {
            festoCMMT.PLCMasterControl = cbTakeControl.Checked;
            gbControl.Enabled = cbTakeControl.Checked;
        }



        #endregion
    }
}
