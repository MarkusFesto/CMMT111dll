﻿namespace CMMT_EP_ModbusTCP
{
    partial class frSample
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbConnect = new System.Windows.Forms.Label();
            this.btConnect = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txIPAddress = new System.Windows.Forms.TextBox();
            this.tCycle = new System.Windows.Forms.Timer(this.components);
            this.txTemp = new System.Windows.Forms.TextBox();
            this.btTemp = new System.Windows.Forms.Button();
            this.btConnectdll = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tdll = new System.Windows.Forms.Timer(this.components);
            this.lbStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbConnect
            // 
            this.lbConnect.AutoSize = true;
            this.lbConnect.Location = new System.Drawing.Point(314, 147);
            this.lbConnect.Name = "lbConnect";
            this.lbConnect.Size = new System.Drawing.Size(102, 17);
            this.lbConnect.TabIndex = 7;
            this.lbConnect.Text = "Not Connected";
            // 
            // btConnect
            // 
            this.btConnect.Location = new System.Drawing.Point(165, 122);
            this.btConnect.Name = "btConnect";
            this.btConnect.Size = new System.Drawing.Size(143, 42);
            this.btConnect.TabIndex = 6;
            this.btConnect.Text = "Connect";
            this.btConnect.UseVisualStyleBackColor = true;
            this.btConnect.Click += new System.EventHandler(this.BtConnect_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "IP Address:";
            // 
            // txIPAddress
            // 
            this.txIPAddress.Location = new System.Drawing.Point(201, 39);
            this.txIPAddress.Name = "txIPAddress";
            this.txIPAddress.Size = new System.Drawing.Size(107, 22);
            this.txIPAddress.TabIndex = 4;
            this.txIPAddress.Text = "127.0.0.1";
            this.txIPAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tCycle
            // 
            this.tCycle.Tick += new System.EventHandler(this.TCycle_Tick);
            // 
            // txTemp
            // 
            this.txTemp.Location = new System.Drawing.Point(134, 186);
            this.txTemp.Name = "txTemp";
            this.txTemp.Size = new System.Drawing.Size(115, 22);
            this.txTemp.TabIndex = 8;
            // 
            // btTemp
            // 
            this.btTemp.Location = new System.Drawing.Point(101, 240);
            this.btTemp.Name = "btTemp";
            this.btTemp.Size = new System.Drawing.Size(147, 41);
            this.btTemp.TabIndex = 9;
            this.btTemp.Text = "Write";
            this.btTemp.UseVisualStyleBackColor = true;
            this.btTemp.Click += new System.EventHandler(this.BtTemp_Click);
            // 
            // btConnectdll
            // 
            this.btConnectdll.Location = new System.Drawing.Point(433, 122);
            this.btConnectdll.Name = "btConnectdll";
            this.btConnectdll.Size = new System.Drawing.Size(143, 42);
            this.btConnectdll.TabIndex = 10;
            this.btConnectdll.Text = "Connect";
            this.btConnectdll.UseVisualStyleBackColor = true;
            this.btConnectdll.Click += new System.EventHandler(this.BtConnectdll_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(202, 67);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(107, 22);
            this.textBox1.TabIndex = 11;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "Extended Parameter:";
            this.label2.Click += new System.EventHandler(this.Label2_Click);
            // 
            // tdll
            // 
            this.tdll.Enabled = true;
            this.tdll.Tick += new System.EventHandler(this.Tdll_Tick);
            // 
            // lbStatus
            // 
            this.lbStatus.AutoSize = true;
            this.lbStatus.Location = new System.Drawing.Point(430, 167);
            this.lbStatus.Name = "lbStatus";
            this.lbStatus.Size = new System.Drawing.Size(48, 17);
            this.lbStatus.TabIndex = 13;
            this.lbStatus.Text = "Status";
            // 
            // frSample
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbStatus);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btConnectdll);
            this.Controls.Add(this.btTemp);
            this.Controls.Add(this.txTemp);
            this.Controls.Add(this.lbConnect);
            this.Controls.Add(this.btConnect);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txIPAddress);
            this.Name = "frSample";
            this.Text = "Sample";
            this.Load += new System.EventHandler(this.FrMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbConnect;
        private System.Windows.Forms.Button btConnect;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txIPAddress;
        private System.Windows.Forms.Timer tCycle;
        private System.Windows.Forms.TextBox txTemp;
        private System.Windows.Forms.Button btTemp;
        private System.Windows.Forms.Button btConnectdll;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer tdll;
        private System.Windows.Forms.Label lbStatus;
    }
}