﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EasyModbus;
using CMMTt111;

namespace CMMT_EP_ModbusTCP
{
    public partial class frSample : Form
    {
        ModbusClient modbusCMMT;
        festoCMMT festoCMMT = new festoCMMT();

        public frSample()
        {
            InitializeComponent();
        }

        private void FrMain_Load(object sender, EventArgs e)
        {

        }

        private void BtConnect_Click(object sender, EventArgs e)
        {
            if (btConnect.Text == "Connect")
            {
                try
                {
                    modbusCMMT = new ModbusClient(txIPAddress.Text, 502);  //Ip-Address and Port of Modbus-TCP-Server
                    modbusCMMT.Connect();  //Connect to Server
                    btConnect.Text = "Disconnect";
                    lbConnect.Text = "Connected";
                    tCycle.Enabled = true;
                }
                catch (Exception ex)
                {
                    lbConnect.Text = ex.ToString();
                    btConnect.Text = "Connect";
                    //throw;
                }
            }
            else
            {
                modbusCMMT.Disconnect();
                btConnect.Text = "Connect";
                lbConnect.Text = "Not Connected";
                tCycle.Enabled = false;
            }
        }

        private void TCycle_Tick(object sender, EventArgs e)
        {
            pdStandard standardCMMT = new pdStandard();

            // Read input - start address: 30000
            // Read standard 12 input word process data from CMMT
            int[] readinputStandardpd = modbusCMMT.ReadInputRegisters(0, 12);
            standardCMMT.readIW(readinputStandardpd);
            

            // Process
            txTemp.Text = readinputStandardpd[0].ToString();




            // Write output
            // Write standard 12 output word process data to CMMT
            modbusCMMT.WriteMultipleRegisters
                (0, new int[] 
                    { standardCMMT.OW0(), standardCMMT.OW1(), standardCMMT.OW2(),
                      standardCMMT.OW3(), standardCMMT.OW4(), standardCMMT.OW5(),
                      standardCMMT.OW6(), standardCMMT.OW7(), standardCMMT.OW8(),
                      standardCMMT.OW9(), standardCMMT.OW10(), standardCMMT.OW11(),
                    }
                );
   
        }

        private void BtTemp_Click(object sender, EventArgs e)
        {
            //Write Output Register
            modbusCMMT.WriteMultipleRegisters(0, new int[] { 123, 234 });

            CMMTt111.pdStandard tambah = new CMMTt111.pdStandard();
            int A;

            A = tambah.tambah(3, 4);
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void BtConnectdll_Click(object sender, EventArgs e)
        {
            try
            {
                if (btConnectdll.Text == "Connect")
                {
                    lbStatus.Text = "Connecting..";
                    festoCMMT.connectModbustcp(txIPAddress.Text, 502, 0,0);
                    tdll.Enabled = true;
                }
                else
                {
                    festoCMMT.disconnectModbustcp();
                }
            }
            catch
            {
                tdll.Enabled = false;
                lbStatus.Text = "Can't connect";
            }
        }

        private void Tdll_Tick(object sender, EventArgs e)
        {
            try
            {
                if (festoCMMT.connectedModbustcp())
                {
                    lbStatus.Text = "Connected";
                    btConnectdll.Text = "Disconnect";
                }
                else
                {
                    lbStatus.Text = "Not Connected";
                    btConnectdll.Text = "Connect";
                }
            }
            catch{}
        }
    }
}
